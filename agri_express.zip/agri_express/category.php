<?php include('header.php');
if (isset($_GET['cid'])) {
  $id = $_GET['cid'];
  $id = $conn->real_escape_string($id);
}
if (isset($_GET['sid'])) {
  $id = $_GET['sid'];
  $id = $conn->real_escape_string($id);
}
$sql = "select category_name from category where id=$id";
$category_name = execute_query($sql);




?>
<div class="banner-in">
  <div class="container">
    <h1><?= $category_name->result[0]['category_name'] ?></h1>
    <ul class="newbreadcrumb">
      <li><a href="index.php">Home</a></li>
      <li><?= $category_name->result[0]['category_name'] ?></li>
    </ul>
  </div>
</div>
<div id="main-container">
  <div class="container">

    <div class="row">
      <aside class="col-sm-3 hidden-xs" id="column-left">
        <h4 class="widget-title">CATEGORIES</h4>
        <!-- <ul class="category-list"> -->
        <!-- <div foreach ($category_data->result as $item => $key): ?>
            <
            $category_id = $category_data->result[$item]['id'];
            $category_name = $category_data->result[$item]['category_name'];

            $sql = "SELECT name,id FROM sub_category WHERE category_id = $category_id";
            $sub_category_data = execute_query($sql);
            $has_sub = !empty($sub_category_data->result);
            ?>
            <li class="< $has_sub ? 'accordion' : '' ?>">
              <a href="category.php?cid=<= $category_id ?>"><= $category_name ?></a>

              < if ($has_sub): ?>
                <ul style="display: none;">
                  < foreach ($sub_category_data->result as $sub): ?>
                    <li><a href="category.php?cid=<= $category_id ?>&sid=<?= urlencode($sub['id']) ?>"><?= $sub['name']; ?></a></li>
                  <endforeach; ?>
                </ul>
              < endif; ?>
            </li>
                  </div endforeach; ?> -->

        <?php
        // active IDs from URL (cast to int to avoid string/strict-equality bugs)
        $activeCategoryId    = isset($_GET['cid']) ? (int) $_GET['cid'] : 0;
        $activeSubCategoryId = isset($_GET['sid']) ? (int) $_GET['sid'] : 0;
        ?>

        <ul class="category-list">
          <?php
          // guard: ensure category_data->result is available and iterable
          if (!empty($category_data->result) && is_array($category_data->result)) {
            foreach ($category_data->result as $row) {
              // normalize values
              $category_id   = (int) $row['id'];
              $category_name = isset($row['category_name']) ? $row['category_name'] : '';

              // fetch subcategories (adjust execute_query usage if your function returns differently)
              $sql = "SELECT name,id FROM sub_category WHERE category_id = " . $category_id;
              $sub_category_data = execute_query($sql);
              $sub_items = (!empty($sub_category_data->result) && is_array($sub_category_data->result))
                ? $sub_category_data->result
                : [];

              // determine if category should be treated active
              $isActiveCategory = ($activeCategoryId === $category_id);

              // if category not matched by cid, but sid belongs to one of its subitems, mark it active too
              if (!$isActiveCategory && $activeSubCategoryId && $sub_items) {
                foreach ($sub_items as $s) {
                  if ((int)$s['id'] === $activeSubCategoryId) {
                    $isActiveCategory = true;
                    break;
                  }
                }
              }

              $li_classes = trim(($sub_items ? 'accordion' : '') . ' ' . ($isActiveCategory ? 'active-category' : ''));
          ?>
              <li class="<?= $li_classes ?>">
                <a href="category.php?cid=<?= $category_id ?>" class="<?= $isActiveCategory ? 'active' : '' ?>">
                  <?= htmlspecialchars($category_name, ENT_QUOTES, 'UTF-8') ?>
                </a>

                <?php if ($sub_items): ?>
                  <ul style="display: <?= $isActiveCategory ? 'block' : 'none' ?>;">
                    <?php foreach ($sub_items as $sub):
                      $sub_id = (int)$sub['id'];
                      $sub_name = isset($sub['name']) ? $sub['name'] : '';
                      $isActiveSub = ($activeSubCategoryId === $sub_id);
                    ?>
                      <li>
                        <a href="category.php?cid=<?= $category_id ?>&amp;sid=<?= $sub_id ?>"
                          class="<?= $isActiveSub ? 'active-sub' : '' ?>">
                          <?= htmlspecialchars($sub_name, ENT_QUOTES, 'UTF-8') ?>
                        </a>
                      </li>
                    <?php endforeach; ?>
                  </ul>
                <?php endif; ?>
              </li>
          <?php
            }
          }
          ?>
        </ul>

        </ul>

      </aside>
      <div class="col-sm-9" id="content">
        <div class="search-bar">
          <div class="row">
            <div class="col-md-4 col-sm-12"><a id="compare-total" href="#">Product Compare (0)</a></div>
            <div class="col-md-2 col-sm-2 text-right">
              <label for="input-sort" class="control-label">Sort By:</label>
            </div>
            <div class="col-md-3  col-sm-5 text-right">
              <select onchange="location = this.value;" class="form-control" id="input-sort">
                <option selected="selected">Default</option>
                <option>Name (A - Z)</option>
                <option>Name (Z - A)</option>
                <option>Price (Low &gt; High)</option>
                <option>Price (High &gt; Low)</option>
              </select>
            </div>
            <div class="col-md-1 col-sm-3 text-right">
              <label for="input-limit" class="control-label">Show:</label>
            </div>
            <div class="col-md-2 col-sm-2 text-right">
              <select onchange="location = this.value;" class="form-control" id="input-limit">
                <option selected="selected">12</option>
                <option>4</option>
                <option>6</option>
                <option>8</option>
                <option>10</option>
              </select>
            </div>
          </div>
        </div>
        <br>
        <div class="row">
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product1.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product2.jpg" alt="" title="" class="img-responsive" />


              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product3.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product4.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product5.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product6.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product7.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product8.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product1.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product2.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product3.jpg" alt="" title="" class="img-responsive" />

              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
          <div class="product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12">
            <div class="product-thumb transition">
              <div class="image">
                <img src="images/product4.jpg" alt="" title="" class="img-responsive" />
              </div>
              <div class="caption">
                <h4><a href="#">Chapron Sec 10000</a></h4>
                <div class="rating">
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                  <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                </div>
                <p class="price">&#8364; 187.00</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 text-left"></div>
          <div class="col-sm-6 text-right">Showing 1 to 12 of 12 (1 Pages)</div>
        </div>
      </div>
    </div>

  </div>
</div>
<style>
  .category-list a.active {
    font-weight: bold;
    color: #007bff;
  }

  .category-list a.active-sub {
    text-decoration: underline;
    color: #dc3545;
  }

  .category-list li.active-category>a {
    font-weight: bold;
    color: #28a745;
  }
</style>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    const accordions = document.querySelectorAll(".category-list .accordion");

    accordions.forEach(item => {
      const subMenu = item.querySelector("ul");

      if (subMenu) {
        if (subMenu.style.display === "") {
          subMenu.style.display = "none";
        }

        item.querySelector("a").addEventListener("click", function(e) {
          e.preventDefault();

          if (subMenu.style.display === "none") {
            subMenu.style.display = "block";
            subMenu.previousElementSibling.classList.add('active');
          } else {
            subMenu.style.display = "none";
            subMenu.previousElementSibling.classList.remove('active');
          }
        });
      }
    });
  });
</script>


<?php include('footer.php'); ?>