<?php include('header.php');
if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $id = $conn->real_escape_string($id);
}
$sql = "SELECT p.id,
       p.name AS product_name,
       p.price,
       p.description,
       c.category_name,
       sc.name AS sub_category_name,
       p.availability,
       p.featured_image,
       p.featured_product,
       p.special_product,
       p.created_at,
       p.updated_at
FROM product p
INNER JOIN category c ON p.category_id = c.id
INNER JOIN sub_category sc ON p.sub_category_id = sc.id
WHERE p.id=$id";
$product_info = execute_query($sql);
// var_dump($product_info);


$sql = "select * from images
where product_id=$id
group by image_src";


$product_images = execute_query($sql);
// var_dump($product_images);
?>

<div class="banner-in">
  <div class="container">
    <h1><?= $product_info->result[0]['product_name']; ?></h1>
    <ul class="newbreadcrumb">
      <li><a href="#">Home</a></li>
      <li><a href="#"><?= $product_info->result[0]['category_name']; ?></a></li>
      <li><a href="#"><?= $product_info->result[0]['sub_category_name']; ?></li>
      <li><?= $product_info->result[0]['product_name']; ?></li>
    </ul>
  </div>
</div>
<div id="main-container">
  <div class="container">
    <div class="zoom-result" id="zoomResult"></div>
    <div class="row">
      <div class="col-sm-12" id="content">

        <div class="row ">
          <div class="col-sm-7">

            <div class="row gx-2 justify-content-center " >

              <div class="col-md-2 p-0" style="height:400px; overflow-y: scroll; padding: 0; ">
                <?php foreach ($product_images->result as $image => $key): ?>
                  <img style="border:1px solid #333; margin-bottom:6px;" src="admin/images/product_thumb/<?= $product_images->result[$image]['image_src']; ?>">
                <?php endforeach; ?>
              </div>

              <div class="col-md-10 image-box" id="imageBox">
                <img style="border:1px solid #333;" id="mainImage" class="border border-primary" title="Closamectin Solution for Injection" src="admin/images/product_medium/<?= $product_info->result[0]['featured_image']; ?>">
                <div class="zoom-lens" id="lens"></div>

              </div>

            </div>




          </div>
          <div class="col-sm-5">
            <div class="pdoduct-details">
              <div class="pdoduct-header">
                <h1><?= $product_info->result[0]['product_name']; ?></h1>

                <h2>₹<?= $product_info->result[0]['price']; ?></h2>
                <button onclick="wishlist.add('40');" title="" class="btn btn-wishlist" data-toggle="tooltip" type="button" data-original-title="Add to Wish List"><i class="fa fa-heart"></i></button>
              </div>
              <hr>
              <ul class="list-unstyled">
                <li>Availability: <?= $product_info->result[0]['availability']; ?> </li>
              </ul>
              <hr>
              <h4>Description</h4>
              <p><?= $product_info->result[0]['description']; ?></p>

              <div id="product">
                <div class="form-group clearfix">
                  <label for="input-quantity" class="control-label">Qty</label>
                  <input type="text" class="form-control" id="input-quantity" size="2" value="1" name="quantity" vk_106cf="subscribed">
                  <input type="hidden" value="40" name="product_id">
                  <button class="btn btn-default btn-lg" data-loading-text="Loading..." id="button-cart" type="button">Add to Cart</button>
                </div>
              </div>
              <hr>
              <div class="rating">
                <div class="row">
                  <div class="col-lg-6">
                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i></span>
                    <a onclick="$('a[href=\'#tab-review\']').trigger('click'); return false;" href="">0 reviews</a> / <a onclick="$('a[href=\'#tab-review\']').trigger('click'); return false;" href="">Write a review</a>
                  </div>
                  <div class="col-lg-6">
                    <div class="pull-right">
                      <img src="images/addthis.jpg" alt="">
                    </div>
                  </div>
                </div>
                <hr>
              </div>
            </div>
          </div>
        </div>

        <br>

        <ul class="nav nav-tabs">
          <li class="active"><a data-toggle="tab" href="#tab-description">Description</a></li>
          <li><a data-toggle="tab" href="#tab-review">Reviews (0)</a></li>
        </ul>
        <div class="tab-content">
          <div id="tab-description" class="tab-pane active">
            <p class="intro">Closamectin Injection for Cattle is a unique and powerful combination of ivermectin, a broad spectrum persistent anti-parasiticide and closantel, a powerful, early-acting flukicide – offering 4in1 treatment of late immature and adult fluke, GIT worms, lungworms and external parasites.</p>
          </div>
          <div id="tab-review" class="tab-pane">
            <form id="form-review" class="form-horizontal">
              <div id="review">
                <p>There are no reviews for this product.</p>
              </div>
              <h2>Write a review</h2>
              <div class="form-group required">
                <div class="col-sm-12">
                  <label for="input-name" class="control-label">Your Name</label>
                  <input type="text" class="form-control" id="input-name" value="" name="name" vk_106cf="subscribed">
                </div>
              </div>
              <div class="form-group required">
                <div class="col-sm-12">
                  <label for="input-review" class="control-label">Your Review</label>
                  <textarea class="form-control" id="input-review" rows="5" name="text"></textarea>
                  <div class="help-block"><span class="text-danger">Note:</span> HTML is not translated!</div>
                </div>
              </div>
              <div class="form-group required">
                <div class="col-sm-12">
                  <label class="control-label">Rating</label>
                  &nbsp;&nbsp;&nbsp; Bad&nbsp;
                  <input type="radio" value="1" name="rating">
                  &nbsp;
                  <input type="radio" value="2" name="rating">
                  &nbsp;
                  <input type="radio" value="3" name="rating">
                  &nbsp;
                  <input type="radio" value="4" name="rating">
                  &nbsp;
                  <input type="radio" value="5" name="rating">
                  &nbsp;Good
                </div>
              </div>
              <div class="buttons clearfix">
                <div class="pull-right">
                  <button class="btn btn-primary" data-loading-text="Loading..." id="button-review" type="button">Continue</button>
                </div>
              </div>
            </form>
          </div>
        </div>

        <div class="product-carousel relater-product">
          <h3>Related Products</h3>
          <div class="row">
            <div id="carouse21" class="owl-carousel">
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product1.jpg" alt="" title="" class="img-responsive" />

                    </div>
                    <div class="caption">
                      <h4><a href="#">Chapron Sec 10000</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product2.jpg" alt="" titl="" class="img-responsive" />
                    </div>
                    <div class="caption">
                      <h4><a href="#">Pel Solar Fencer 702s</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fea-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product3.jpg" alt="" title="" class="img-responsive" />

                    </div>
                    <div class="caption">
                      <h4><a href="#">Pel Solar Fencer 702s</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product4.jpg" alt="" title="" class="img-responsive" />

                    </div>
                    <div class="caption">
                      <h4><a href="#">Screw Insulators 25 Pack</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product1.jpg" alt="" title="" class="img-responsive" />

                    </div>
                    <div class="caption">
                      <h4><a href="#">Chapron Sec 10000</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product2.jpg" alt="" title="" class="img-responsive" />

                    </div>
                    <div class="caption">
                      <h4><a href="#">Pel Solar Fencer 702s</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product3.jpg" alt="" title="" class="img-responsive" />

                    </div>
                    <div class="caption">
                      <h4><a href="#">Pel Solar Fencer 702s</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="product-layout">
                  <div class="product-thumb transition">
                    <div class="image">
                      <img src="images/product4.jpg" alt="" title="" class="img-responsive" />

                    </div>
                    <div class="caption">
                      <h4><a href="#">Screw Insulators 25 Pack</a></h4>
                      <div class="rating">
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                        <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i><i class="fa fa-star-o fa-stack-2x"></i></span>
                      </div>
                      <p class="price">&#8364; 187.00</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <script type="text/javascript">
          $('#carouse21').owlCarousel({
            items: 4,
            autoPlay: 3000,
            navigation: true,
            navigationText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
            pagination: false,
            autoPlay: false,
            itemsDesktopSmall: [1199, 3],
            itemsTablet: [991, 3],
            itemsTabletSmall: [767, 2],
          });
        </script>

      </div>
    </div>


    <script>
      const imageBox = document.getElementById('imageBox');
      const mainImage = document.getElementById('mainImage');
      const lens = document.getElementById('lens');
      const zoomResult = document.getElementById('zoomResult');
      zoomResult.style.display = 'none';
      const zoom = 2;



      imageBox.addEventListener('mousemove', moveLens);
      imageBox.addEventListener('mouseenter', () => {
        zoomResult.style.backgroundImage = `url(admin/images/product_large/${(mainImage.src).split('/').pop()})`;
        console.log(mainImage.src);
        zoomResult.style.display = 'block';
        lens.style.display = "block"
      });
      imageBox.addEventListener('mouseleave', () => {
        zoomResult.style.display = "none";
        lens.style.display = "none"
      });

      function moveLens(e) {
        const rect = imageBox.getBoundingClientRect();
        const x = e.pageX - rect.left - window.pageXOffset;
        const y = e.pageY - rect.top - window.pageYOffset;

        let lensX = x - lens.offsetWidth / 2;
        let lensY = y - lens.offsetHeight / 2;

        // Clamp lens position
        lensX = Math.max(0, Math.min(lensX, imageBox.offsetWidth - lens.offsetWidth));
        lensY = Math.max(0, Math.min(lensY, imageBox.offsetHeight - lens.offsetHeight));

        lens.style.left = lensX + 'px';
        lens.style.top = lensY + 'px';

        const fx = lensX / imageBox.offsetWidth * zoomResult.offsetWidth;
        const fy = lensY / imageBox.offsetHeight * zoomResult.offsetHeight;

        zoomResult.style.backgroundPosition = `-${fx}px -${fy}px`;
      }


      document.querySelectorAll(".col-md-2 img").forEach(thumb => {
        thumb.addEventListener("mouseenter", () => {

          document.getElementById("mainImage").src = "admin/images/product_medium/" + ((thumb.src).split('/').pop());
          // "admin/images/product_medium/"+
        });
      });
    </script>
    <style>
      .image-box {
        position: relative;
      }

      .image-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        cursor: crosshair !important;
      }

      .zoom-lens {
        position: absolute;
        width: 100px;
        height: 100px;
        background: rgba(255, 255, 255, 0.3);
        pointer-events: none;
        display: none;
        cursor: crosshair !important;
      }

      .zoom-result {
        position: fixed;
        top: 280px;
        right: 100px;
        width: 538px;
        height: 406px;
        border: 1px solid #ccc;
        background-repeat: no-repeat;
        background-size: 1000px;
        z-index: 999;
        pointer-events: none !important;

      }
    </style>
    </style>
  </div>
</div>

<?php include('footer.php'); ?>