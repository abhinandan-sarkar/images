<?php

// DB connection 
$conn = new mysqli("localhost", "root", "", "agri");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function execute_query($sql){
    global $conn;
    $result=mysqli_query($conn, $sql);
    if(is_bool($result)) return $result;
    $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $return = [
        'num_rows' => $result->num_rows,
        'result' => $rows,
       
    ];
    mysqli_free_result($result);
    return  (object)$return;
    // 'row' => $result->num_rows > 0 ? $rows[0] : null
    
}



?>