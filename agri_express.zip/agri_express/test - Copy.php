-- Adminer 4.8.4 MySQL 9.1.0 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin` (`id`, `user_name`, `password`, `created_at`, `updated_at`) VALUES
(1,	'root',	'$2y$10$3GAJqR8ZObavqqYArFzbE.CFhWauFsIUUf5IBeS.6quYBe4M1rvIK',	'2025-08-22 09:53:38',	NULL),
(2,	'abhi',	'$2y$10$AykmPZ57pH9z4KW8oCQ0huevn7NiJU59/aLzZu3CqBv.JRsYe9.Ly',	'2025-08-22 09:57:35',	NULL);

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `category` (`id`, `category_name`, `image`, `order`, `status`, `created_at`, `updated_at`) VALUES
(9,	'Animal',	'animal_1755939371.png',	1,	'Active',	'2025-08-23 14:26:10',	NULL),
(10,	'Seed',	'seed_1755940886.png',	2,	'Active',	'2025-08-23 14:51:26',	NULL),
(11,	'Tool',	'tool_1755941121.png',	3,	'Active',	'2025-08-23 14:55:20',	NULL),
(12,	'Abhi',	'abhi_1756211626.png',	0,	'Active',	'2025-08-26 18:03:46',	NULL);

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image_src` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `images` (`id`, `image_src`, `product_id`) VALUES
(49,	'img_68ac33771f512.jpg',	45),
(50,	'img_68ac33771f512.jpg',	45),
(51,	'img_68ac33771f512.jpg',	45),
(52,	'img_68ac33771f512.jpg',	45),
(53,	'img_68ac338037ff0.jpg',	45),
(54,	'img_68ac338037ff0.jpg',	45),
(55,	'img_68ac338037ff0.jpg',	45),
(56,	'img_68ac338037ff0.jpg',	45),
(57,	'img_68ac3385533f6.jpg',	45),
(58,	'img_68ac3385533f6.jpg',	45),
(59,	'img_68ac3385533f6.jpg',	45),
(60,	'img_68ac3385533f6.jpg',	45);

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `description` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int unsigned NOT NULL,
  `sub_category_id` int unsigned NOT NULL,
  `availability` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured_image` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `special_product` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured_product` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `sub_category_id` (`sub_category_id`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_ibfk_2` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_category` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product` (`id`, `name`, `price`, `description`, `category_id`, `sub_category_id`, `availability`, `featured_image`, `special_product`, `featured_product`, `created_at`, `updated_at`) VALUES
(45,	'Labrador',	5000,	'Aut labore qui quae ',	11,	10,	'yes',	'featured_68ac3372ac75b.jpg',	'yes',	'no',	'2025-08-25 09:57:11',	'0000-00-00 00:00:00');

DROP TABLE IF EXISTS `sub_category`;
CREATE TABLE `sub_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int unsigned NOT NULL,
  `order` int NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `sub_category_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sub_category` (`id`, `name`, `category_id`, `order`, `status`, `created_at`, `updated_at`) VALUES
(10,	'Dog',	9,	0,	' Active',	'2025-08-23 14:28:31',	'0000-00-00 00:00:00'),
(11,	'Cow',	9,	0,	' Active',	'2025-08-23 14:29:09',	'0000-00-00 00:00:00');

-- 2025-08-26 13:27:55
