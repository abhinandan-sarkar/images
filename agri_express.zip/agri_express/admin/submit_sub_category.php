<?php
include('database.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category_id = $_POST['category'] ?? '';
    $sub_category_name = $_POST['sub_category_name'] ?? '';
    $order = $_POST['order'] ?? '';
    $status = $_POST['status'] ?? '';
    $sql = "INSERT INTO `sub_category`(`name`, `category_id`, `order`, `status`, `created_at`) VALUES ('$sub_category_name','$category_id','$order',' $status',now())";

    if (empty($category_id) || empty($sub_category_name)) {

        $_SESSION['flash'] = [
            'type' => 'danger',
            'message' => 'Something went wrong.'
        ];
       header('Location: sub_category.php');
    } else {
        mysqli_query($conn, $sql) or die('There is something wrong');

        $_SESSION['flash'] = [
            'type' => 'success',
            'message' => "Data added successfully!"
        ];
        header('Location: sub_category.php');
    }
}
