<?php include('header.php'); ?>
<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Edit Order</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="discount.php">Discount</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit Order</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-primary card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Order Details</div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->

                    <form id="image_form" action="submit_image.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="page_id" value="" >

                        <!--begin::Body-->
                        <div class="card-body">

                            <table style="width:100%; border-collapse:collapse;">
                                <tr>
                                    <td colspan="2">
                                        <div class="card-header p-0">
                                            <div class="card-title">Product Details</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Product 1</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="" readonly  >

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <div class="form-group">
                                            <label for="exampleDateInput" class="form-label">Quantity</label>
                                            <input type="number" class="form-control" id="exampleDateInput" readonly>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2">
                                        <div class="card-header p-0">
                                            <div class="card-title">Address Details</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Delivery Address</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Billing Address</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>


                                <tr>
                                    <td colspan="2">
                                        <div class="card-header p-0">
                                            <div class="card-title">Billing Details</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Sub Total</label>
                                        <input type="number" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Eco Tax(-2.00)</label>
                                        <input type="number" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>



                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Vat(20%)</label>
                                        <input type="number" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Discount</label>
                                        <input type="number" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>

                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Total</label>
                                        <input type="number" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">
                                    </td>
                                </tr>



                                <tr>
                                    <td colspan="2">
                                        <div class="card-header p-0">
                                            <div class="card-title">Payment Details</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Payment Mode</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Order Date</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">
                                    </td>
                                </tr>


                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Transaction Id</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Order Status</label>
                                        <select class="form-select" id="availability" name="availability">
                                            <option value="In Stock" selected>Processing</option>
                                            <option value="Out of Stock">Shipped</option>
                                            <option value="In Stock" selected>Delivered</option>
                                            <option value="Out of Stock">On Hold</option>
                                            <option value="In Stock" selected>Completed</option>
                                        </select>
                                    </td>
                                </tr>


                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Payment Status</label>
                                           <select class="form-select" id="availability" name="availability">
                                            <option value="In Stock" selected>Pending</option>
                                            <option value="In Stock" selected>Complete</option>
                                            <option value="In Stock" selected>Refunded</option>
                                            <option value="In Stock" selected>Failed</option>
                                            <option value="In Stock" selected>Abandoned</option>
                                            <option value="In Stock" selected>Revoked</option>
                                            <option value="Out of Stock">Preapproved</option>
                                        </select>

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">
                                    </td>
                                </tr>













                            </table>
                        </div>

                        <!--end::Body-->
                        <!--begin::Footer-->
                        <div class="card-footer text-center d-flex justify-content-center gap-4">
                            <button type="submit" class="btn btn-success text-white">Add</button>
                            <button type="reset" class="btn btn-warning text-white">Reset</button>
                        </div>
                        <!--end::Footer-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>

<?php include('footer.php'); ?>