<?php include('header.php'); ?>
<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Edit Customer</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="discount.php">Customer</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit Customer</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-primary card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Customer Details</div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->

                    <form id="image_form" action="submit_image.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="page_id" value="">

                        <!--begin::Body-->
                        <div class="card-body">

                            <table style="width:100%; border-collapse:collapse;">
                                <tr>
                                    <td colspan="2">
                                        <div class="card-header p-0">
                                            <div class="card-title">Personal Details</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">First Name</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="" readonly>

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <div class="form-group">
                                            <label for="exampleDateInput" class="form-label">Last Name</label>
                                            <input type="text" class="form-control" id="exampleDateInput" readonly>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="" readonly>

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <div class="form-group">
                                            <label for="exampleDateInput" class="form-label">Telephone</label>
                                            <input type="number" class="form-control" id="exampleDateInput" readonly>
                                        </div>
                                    </td>
                                </tr>

                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Fax</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="" readonly>

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <div class="form-group">
                                            <label for="exampleDateInput" class="form-label">Status</label>
                                             <select class="form-select" id="availability" name="availability">
                                            <option value="In Stock" selected>Active</option>
                                        </select>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <div class="card-header p-0">
                                            <div class="card-title">Address 1</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Company</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Address Line 1</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Address Line 2</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">City</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>


                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Post Code</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Country</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2"  style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Region</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2">
                                        <div class="card-header p-0">
                                            <div class="card-title">Address 2</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Company</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Address Line 1</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Address Line 2</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">City</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>


                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Post Code</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Product Name" name="image_nickname" value="">

                                    </td>
                                    <td style="padding:10px; vertical-align:top;">

                                        <label for="category" class="form-label">Country</label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="" name="image_nickname" value="">
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2"  style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Region</label>
                                        <select class="form-select" id="availability" name="availability">
                                            <option value="In Stock" selected>West Bengal</option>
                                        </select>
                                    </td>
                                </tr>































                            </table>
                        </div>

                        <!--end::Body-->
                        <!--begin::Footer-->
                        <div class="card-footer text-center d-flex justify-content-center gap-4">
                            <button type="submit" class="btn btn-success text-white">Add</button>
                            <button type="reset" class="btn btn-warning text-white">Reset</button>
                        </div>
                        <!--end::Footer-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>

<?php include('footer.php'); ?>