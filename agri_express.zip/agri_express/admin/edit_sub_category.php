<?php include('header.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $id = $conn->real_escape_string($id);
}
$sql = "
SELECT sub_category.id  ,sub_category.name, sub_category.category_id, sub_category.order,
sub_category.status,category.category_name
FROM  sub_category 
INNER JOIN category ON sub_category.category_id = category.id
;";
$result = execute_query($sql);
// var_dump($result);
$sql = "SELECT `id`, `category_name` FROM `category`";
$category_data = execute_query($sql);
// var_dump($category_data->result[0]);
?>
<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Edit Sub Category</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="sub_category.php">Sub Category</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit Sub Category</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-primary card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Edit Sub Category</div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->
                    <form id="image_form" action="submit_image.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="subcategory_id" value="<?= $result->row['id'] ?>">
                        <!--begin::Body-->
                        <div class="card-body">
                            <table style="width:100%; border-collapse:collapse;">
                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="category" class="form-label">Category <span style="color:red;font-size:20px;">*</span></label>
                                        <select class="form-select" style="cursor:pointer;" id="category" name="category">
                                            <?php
                                                foreach ($category_data->result as $option_value => $key) {
                                                    $selected_attribute = ($category_data->result[$option_value]['category_name']  == $result->row['category_name']) ? 'selected="selected"' : '';
                                                    echo '<option value="' . htmlspecialchars($category_data->result[$option_value]['id']) . '" ' . $selected_attribute . '>' . htmlspecialchars($category_data->result[$option_value]['category_name']) . '</option>';
                                                }
                                            ?>
                                        </select>



                                    </td>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="image_nickname" class="form-label">Name <span style="color:red;font-size:20px;">*</span></label>
                                        <input type="text" class="form-control" id="image_nickname" placeholder="Sub Category Name" name="image_nickname" value="<?= $result->row['name'] ?>">
                                    </td>
                                </tr>

                                <tr>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="image_page_image_order_number" class="form-label">Order Number</label>
                                        <input type="number" class="form-control" id="image_page_image_order_number" name="image_page_image_order_number" value="<?= $result->row['order'] ?>">
                                    </td>
                                    <td style="padding:10px; vertical-align:top;">
                                        <label for="image_page_image_status" class="form-label">Status</label>
                                        <select class="form-select" style="cursor:pointer;" id="image_page_image_status" name="image_page_image_status">
                                            <?php
                                            $options = ["Active", "Inactive"];
                                            foreach ($options as $option_value) {
                                                $selected_attribute = ($option_value == $result->row['status']) ? 'selected="selected"' : '';
                                                echo '<option value="' . htmlspecialchars($option_value) . '" ' . $selected_attribute . '>' . htmlspecialchars($option_value) . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <!--end::Body-->
                        <!--begin::Footer-->
                        <div class="card-footer text-center d-flex justify-content-center gap-4">
                            <button type="submit" class="btn btn-success text-white">Update</button>
                            <button type="reset" class="btn btn-warning text-white">Reset</button>
                        </div>
                        <!--end::Footer-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>

<?php include('footer.php'); ?>