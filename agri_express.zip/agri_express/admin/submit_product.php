<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "agri");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Resize function
function resizeImage($sourcePath, $destPath, $newWidth) {
    list($width, $height, $type) = getimagesize($sourcePath);
    $ratio = $height / $width;
    $newHeight =round($newWidth * $ratio);
    $thumb = imagecreatetruecolor($newWidth, $newHeight);

    switch ($type) {
        case IMAGETYPE_JPEG:
            $source = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $source = imagecreatefrompng($sourcePath);
            imagealphablending($thumb, false);
            imagesavealpha($thumb, true);
            break;
        case IMAGETYPE_GIF:
            $source = imagecreatefromgif($sourcePath);
            break;
        default:
            return false;
    }

    imagecopyresampled($thumb, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

    switch ($type) {
        case IMAGETYPE_JPEG:
            imagejpeg($thumb, $destPath);
            break;
        case IMAGETYPE_PNG:
            imagepng($thumb, $destPath);
            break;
        case IMAGETYPE_GIF:
            imagegif($thumb, $destPath);
            break;
    }

    imagedestroy($thumb);
    imagedestroy($source);
    return true;
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $category_id = $_POST['category'] ?? '';
    $sub_category_id = $_POST['subcategory'] ?? '';
    $product_name = $_POST['product_name'] ?? '';
    $product_price = $_POST['product_price'] ?? '';
    $product_desc = $_POST['product_desc'] ?? '';
    $availability = isset($_POST['availability']) ? 'In Stock' : 'Out of Stock';
    $special_product = isset($_POST['special_product']) ? 'yes' : 'no';
    $featured_product = isset($_POST['featured_product']) ? 'yes' : 'no';

    // Validate required fields
    if (empty($category_id) || empty($sub_category_id) || empty($product_name) || empty($product_price) || empty($_FILES['featured_image']['name'])) {
        die("Missing required fields.");
    }

    // Create folders if not exist
    $folders = ["images/product_original", "images/product_featured","images/product_large", "images/product_medium", "images/product_small", "images/product_thumb"];
    foreach ($folders as $folder) {
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }
    }

    // Handle featured image
    $featured_image_file = $_FILES['featured_image'];
    $ext = strtolower(pathinfo($featured_image_file['name'], PATHINFO_EXTENSION));
    $featured_image_name = uniqid("featured_") . "." . $ext;
    $original_path = "images/product_original/" . $featured_image_name;

    if (move_uploaded_file($featured_image_file['tmp_name'], $original_path)) {
        // Resize to 255px and save in medium folder
        $resized_path = "images/product_large/" . $featured_image_name;
        resizeImage($original_path, $resized_path, 1000);
        $resized_path = "images/product_medium/" . $featured_image_name;
        resizeImage($original_path, $resized_path, 450);
        $resized_path = "images/product_small/" . $featured_image_name;
        resizeImage($original_path, $resized_path, 255);
        $resized_path = "images/product_thumb/" . $featured_image_name;
        resizeImage($original_path, $resized_path, 108);
    } else {
        die("Failed to upload featured image.");
    }

    // Insert product into database
    $created_at = date("Y-m-d H:i:s");
    $stmt = $conn->prepare("INSERT INTO product (name, price, description, category_id, sub_category_id, availability, featured_image, special_product, featured_product, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdsiisssss", $product_name, $product_price, $product_desc, $category_id, $sub_category_id, $availability, $featured_image_name, $special_product, $featured_product, $created_at);
    $stmt->execute();
    $product_id = $stmt->insert_id;
    $stmt->close();

    // Handle gallery images
    if (!empty($_FILES['gallery_image']['name'][0])) {
        foreach ($_FILES['gallery_image']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['gallery_image']['error'][$key] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['gallery_image']['name'][$key], PATHINFO_EXTENSION));
                $base_name = uniqid("img_");
                $original_name = $base_name . "." . $ext;
                $original_path = "images/product_original/" . $original_name;

                if (move_uploaded_file($tmp_name, $original_path)) {
                    // Resize and save in different folders
                    $sizes = [
                        "product_large" => 1000,
                        "product_medium" => 600,
                        "product_small" => 300,
                        "product_thumb" => 150
                    ];

                    foreach ($sizes as $folder => $size) {
                        $resized_path = "images/$folder/" . $original_name;
                        resizeImage($original_path, $resized_path, $size);

                        // Insert into images table
                        $stmt = $conn->prepare("INSERT INTO images (image_src, product_id) VALUES (?, ?)");
                        $stmt->bind_param("si", $original_name, $product_id);
                        $stmt->execute();
                        $stmt->close();
                    }
                }
            }
        }
    }

    
}
?>
