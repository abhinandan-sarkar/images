<?php
session_start();
header('Content-Type: application/json');

$conn = mysqli_connect('localhost', 'root', '', 'agri');
if (!$conn) {
    echo json_encode(['message' => 'Database connection failed.']);
    http_response_code(500);
    exit;
}

// Read JSON input
$data = json_decode(file_get_contents("php://input"), true);
$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

// Shield against SQL injection by using prepared statements
function get_user_by_username($username)
{
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM admin WHERE user_name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result || $result->num_rows === 0) {
        return null;
    }

    $rows = $result->fetch_all(MYSQLI_ASSOC);
    mysqli_free_result($result);

    return (object)[
        'num_rows' => count($rows),
        'result' => $rows,
        'row' => $rows[0]
    ];
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($username) || empty($password)) {
        echo json_encode([
            'message' => 'Invalid username or password.',
            'debug' => [
                'username' => '[hidden]',
                'password' => '[hidden]'
            ]
        ]);
        http_response_code(401);
        exit;
    }

    $result = get_user_by_username($username);

    if (!$result || $result->num_rows === 0) {
        echo json_encode([
            'message' => 'Invalid username or password.',
            'debug' => [
                'username' => '[hidden]',
                'password' => '[hidden]',
                'query_result' => '[hidden]'
            ]
        ]);
        http_response_code(401);
        exit;
    }

    $passwordMatch = password_verify($password, $result->row['password']);
    if (!$passwordMatch) {
        echo json_encode([
            'message' => 'Invalid username or password.',
            'debug' => [
                'username' => '[hidden]',
                'password' => '[hidden]',
                'query_result' => '[hidden]',
                'password_match' => '[hidden]'
            ]
        ]);
        http_response_code(401);
        exit;
    }

    $_SESSION['auth_user'] = $result->row;

    echo json_encode([
        'message' => 'Login successful!',
        'debug' => [
            'username' => '[hidden]',
            'query_result' => '[hidden]',
            'password_match' => '[hidden]'
        ]
    ]);
    http_response_code(200);
    // After successful login
    $_SESSION['flash'] = [
        'type' => 'success', 
        'message' => 'Welcome back, you have successfully logged in!'
    ];
}
