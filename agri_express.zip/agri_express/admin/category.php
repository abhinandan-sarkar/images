<?php
include 'header.php';
$sql = "SELECT c.id,
       c.category_name,
       c.order,
       c.status,
       COUNT(sc.id) AS sub_category_count
FROM category c
LEFT JOIN sub_category sc ON sc.category_id = c.id
GROUP BY c.id, c.category_name, c.order, c.status;";

$result = execute_query($sql);
// var_dump($result);
if (isset($_SESSION['flash'])): ?>
    <script>
        var flashType = "<?php echo $_SESSION['flash']['type']; ?>";
        var flashMessage = "<?php echo $_SESSION['flash']['message']; ?>";
    </script>
    <?php unset($_SESSION['flash']); ?>
<?php endif; ?>
?>



<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Category</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Category</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-info card-outline p-0 rounded-0 ">
                    <!--begin::Header-->

                    <!--end::Header-->
                    <div class="card-header d-flex justify-content-between">
                        <a href="category.php" class="btn btn-sm bg-success text-white">All</a>
                        <?php $i = 65;
                        while ($i != 90): ?>
                            <a href="category.php?query=<?= chr($i); ?>" class="btn btn-sm bg-success text-white"><?= chr($i); ?></a>
                        <?php $i++;
                        endwhile; ?>
                    </div>
                    <div class="card-header border-0 pb-0">

                        <form class="d-flex gap-4" role="search" method="get" action="category.php">
                            <div class=" d-inline-flex align-items-center  " style="text-wrap:nowrap; font-weight:bold;">Category Name</div>
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="query">
                            <button class="btn btn-sm btn-success" type="submit">Search</button>
                        </form>
                    </div>
                    <div class="card card-info card-outline  rounded-0">

                        <div class="card rounded-0 border-0 ">
                            <!-- /.card-header -->
                            <div class="card-body card-info card-outline rounded-0 ">
                                <div> </div>
                                <div class="d-flex justify-content-end"><a href="add_category.php" class="btn btn-success mb-2">Add New</a></div>
                                <table class="table table-hover" role="table">
                                    <thead align="center">
                                        <tr>
                                            <th scope="col">Category Name</th>
                                            <th scope="col">Order</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Number of Sub-Category</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody align="center">
                                        <?php
                                        if (isset($_GET['query'])) {
                                            $query = $_GET['query'];
                                            $query = $conn->real_escape_string($query) . '%';

                                            $sql = "SELECT c.id,
                                                        c.category_name,
                                                        c.order,
                                                        c.status,
                                                        COUNT(sc.id) AS sub_category_count
                                                    FROM category c
                                                    LEFT JOIN sub_category sc ON sc.category_id = c.id
                                                    WHERE c.category_name LIKE '$query'
                                                    GROUP BY c.id, c.category_name, c.order, c.status";

                                            // echo $sql;

                                            $result = mysqli_query($conn, $sql);

                                            if (mysqli_num_rows($result) > 0) {
                                                while ($item = mysqli_fetch_assoc($result)) {
                                                    echo "<tr class='align-middle'>
                                                            <td>{$item['category_name']}</td>
                                                            <td>{$item['order']}</td>
                                                            <td>{$item['status']}</td>
                                                            <td>{$item['sub_category_count']}</td>
                                                            <td>
                                                                <a href='edit_category.php?id={$item['id']}' class='btn btn-sm bg-info text-white'>EDIT</a>
                                                                <a href='' class='btn btn-sm bg-danger text-white'>DELETE</a>
                                                            </td>
                                                        </tr>";
                                                }
                                            } else {
                                                echo "<tr><td class='text-danger' colspan='5'>No record found</td></tr>";
                                            }
                                        } else {
                                            // Default query without filter
                                            $sql = "SELECT c.id,
                                                        c.category_name,
                                                        c.order,
                                                        c.status,
                                                        COUNT(sc.id) AS sub_category_count
                                                    FROM category c
                                                    LEFT JOIN sub_category sc ON sc.category_id = c.id
                                                    GROUP BY c.id, c.category_name, c.order, c.status";

                                            $result = mysqli_query($conn, $sql);

                                            while ($item = mysqli_fetch_assoc($result)) {
                                                echo "<tr class='align-middle'>
                                                        <td>{$item['category_name']}</td>
                                                        <td>{$item['order']}</td>
                                                        <td>{$item['status']}</td>
                                                        <td>{$item['sub_category_count']}</td>
                                                        <td>
                                                            <a href='edit_category.php?id={$item['id']}' class='btn btn-sm bg-info text-white'>EDIT</a>
                                                            <a href='' class='btn btn-sm bg-danger text-white'>DELETE</a>
                                                        </td>
                                                    </tr>";
                                            }
                                        }
                                        ?>



                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <!-- <div class="card-footer clearfix ">
                                <ul class="pagination pagination-sm m-0 float-end">
                                    <li class="page-item">
                                        <a class="page-link" href="#">«</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">1</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">2</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">3</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">»</a>
                                    </li>
                                </ul>
                            </div> -->
                        </div>

                    </div>


                </div>













                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>

<script>
    $(function() {
        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            height: 80,
        });

        if (typeof flashType !== 'undefined' && typeof flashMessage !== 'undefined') {
            Toast.fire({
                icon: flashType,
                title: flashMessage,
            });
        }
    });
</script>
<style>
    .swal2-toast {
        padding: 6px !important;
        padding-left: 18px !important;
    }

    .swal2-toast h2:where(.swal2-title) {
        margin: 10px !important;
        padding: 0;
        font-size: 13px !important;
        text-align: initial;
        line-height: 20px;
        font-family: var(--bs-body-font-family) !important;
    }
</style>

 <script>
    const form = document.getElementById("uploadForm");
    const imageInput = document.getElementById("imageInput");

    // Allowed extensions
    const allowedExtensions = ["jpg", "jpeg", "png", "gif", "webp"];

    // On focus remove red border
    imageInput.addEventListener("focus", () => {
      imageInput.classList.remove("error-border");
    });

    // On change validate extension
    imageInput.addEventListener("change", () => {
      const file = imageInput.files[0];
      if (!file) return;

      const ext = file.name.split(".").pop().toLowerCase();
      if (!allowedExtensions.includes(ext)) {
        alert("Invalid file type. Allowed: " + allowedExtensions.join(", "));
        imageInput.value = ""; // clear
        imageInput.classList.add("error-border");
      }
    });

    // On submit validate image dimension
    form.addEventListener("submit", (e) => {
      e.preventDefault(); // stop submission until validated

      const file = imageInput.files[0];
      if (!file) {
        alert("Please select an image.");
        imageInput.classList.add("error-border");
        return;
      }

      const img = new Image();
      img.src = URL.createObjectURL(file);

      img.onload = function () {
        if (img.width < 70 || img.height < 70) {
          alert("Image must be at least 70x70 pixels.");
          imageInput.classList.add("error-border");
        } else {
          alert(" Image is valid. Form submitted!");
          form.submit(); // now submit
        }
      };
    });
  </script>

<!--end::App Main-->
<?php include('footer.php'); ?>

<!--begin::Script-->



<!--end::Script-->

</html>