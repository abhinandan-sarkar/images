<?php include('header.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $id = $conn->real_escape_string($id);
}
// var_dump($id);
$sql = "SELECT p.id,
       p.name AS product_name,
       p.price,
       p.description,
       c.category_name,
       sc.name AS sub_category_name,
       p.availability,
       p.featured_image,
       p.featured_product,
       p.special_product
FROM product p
INNER JOIN category c ON p.category_id = c.id
INNER JOIN sub_category sc ON p.sub_category_id = sc.id
WHERE p.id = $id ";

$result = execute_query($sql);
// var_dump($result);
$sql = "SELECT `id`, `category_name` FROM `category`";
$category_data = execute_query($sql);

$sql = "SELECT `id`, `name` FROM `sub_category`";
$sub_category_data = execute_query($sql);
// var_dump($sub_category_data);

$sql = "SELECT p.name AS product_name,
        p.id,
        i.id,
        GROUP_CONCAT(i.image_src ORDER BY i.id SEPARATOR ', ') AS images
        FROM images i
        INNER JOIN product p ON i.product_id = p.id
        WHERE p.id = $id
        GROUP BY p.id, p.name, i.id
";
// var_dump($sql);
$images_data = execute_query($sql);
// var_dump($images_data);

?>
<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Edit Product</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="product.php">Product</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Edit Product</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-primary card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Product Details</div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->
                    <form id="image_form" action="submit_edit_product.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="product_id" value="<?= $result->row['id']; ?>">
                        <!--begin::Body-->
                        <div class="card-body">
                            <table style="width:100%; border-collapse:collapse;">
                                <tr>
                                    <td style="padding:10px;">
                                        <label for="category" class="form-label">Category <span style="color:red;font-size:20px;">*</span></label>
                                        <select class="form-select" id="category" name="category">
                                            <?php
                                            foreach ($category_data->result as $option_value => $key) {
                                                $selected_attribute = ($category_data->result[$option_value]['category_name']  == $result->row['category_name']) ? 'selected="selected"' : '';
                                                echo '<option value="' . htmlspecialchars($category_data->result[$option_value]['id']) . '" ' . $selected_attribute . '>' . htmlspecialchars($category_data->result[$option_value]['category_name']) . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </td>
                                    <td style="padding:10px;">
                                        <label for="subcategory" class="form-label">Sub Category</label>
                                        <select class="form-select" id="subcategory" name="subcategory">
                                            <?php
                                            foreach ($sub_category_data->result as $option_value => $key) {
                                                $selected_attribute = ($sub_category_data->result[$option_value]['name']  == $result->row['sub_category_name']) ? 'selected="selected"' : '';
                                                echo '<option value="' . htmlspecialchars($sub_category_data->result[$option_value]['id']) . '" ' . $selected_attribute . '>' . htmlspecialchars($sub_category_data->result[$option_value]['name']) . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <td style="padding:10px;">
                                        <label for="product_name" class="form-label">Name <span style="color:red;font-size:20px;">*</span></label>
                                        <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Product Name" value="<?php echo $result->row['product_name']; ?>">
                                    </td>
                                    <td style="padding:10px;">
                                        <label for="product_price" class="form-label">Price <span style="color:red;font-size:20px;">*</span></label>
                                        <input type="number" class="form-control" id="product_price" name="product_price" placeholder="Product Price" value="<?php echo $result->row['price']; ?>">
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2" style="padding:10px;">
                                        <label for="product_description" class="form-label">Description</label>
                                        <textarea class="form-control" id="product_description" rows="3" placeholder="Product Description"><?php echo $result->row['description']; ?></textarea>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2" style="padding:10px; " class="pb-0">
                                        <label for="featured_image" class="form-label">Featured Image <span style="color:red;font-size:20px;">*</span></label>
                                        <div class="image_item_parent mb-2  gap-2 ">
                                            <div class="image_item"><img src="images/product_thumb/<?= $result->row['featured_image']; ?>" alt=""></div>
                                        </div>
                                        <input class="form-control" type="file" id="featured_image" name="featured_image">
                                        <p class="text-info">(Image should be >10MB and minimum 1000×1000 pixels square sized)</p>
                                    </td>

                                </tr>
                                <tr>

                                    <td colspan="2" style="padding:10px;">
                                        <label for="availability" class="form-label">Availability</label>
                                        <select class="form-select" id="availability" name="availability">
                                            <option value="In Stock" selected>In Stock</option>
                                            <option value="Out of Stock">Out of Stock</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="padding:10px;">
                                        <label for="gallery_images" class="form-label">Gallery Image</label>
                                        <div id="preview">
                                            <?php foreach ($images_data->result as $value => $key): ?>
                                                <div style="position: relative; display: inline-block;">
                                                    <img src='images/product_thumb/<?= $images_data->result[$value]['images']; ?>' value='<?= $images_data->result[$value]['id']; ?>' style="width:120px;height:120px;object-fit:cover;border:1px solid #ccc;border-radius:6px;box-shadow:0 2px 5px rgba(0,0,0,.1)">
                                                    <button type="button" style="position:absolute;top:-8px;right:-8px;background:red;color:#fff;border:none;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:14px;line-height:20px">×</button>
                                                </div>

                                            <?php endforeach; ?>

                                        </div>
                                        <input class="form-control" type="file" id="gallery_images" name="gallery_image[]" multiple>
                                        <p class="text-info">**You can select multiple images for the product gallery**</p>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2" style="padding:10px;">
                                        <div class="d-flex justify-content-center gap-5">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="product_type" id="special_product" value="special" checked>
                                                <label class="form-check-label" for="special_product">Add To Special Product</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="product_type" id="featured_product" value="featured">
                                                <label class="form-check-label" for="featured_product">Add To Featured Product</label>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <!--end::Body-->
                        <!--begin::Footer-->
                        <div class="card-footer text-center d-flex justify-content-center gap-4">
                            <button type="submit" class="btn btn-success text-white">Update</button>
                            <button type="reset" class="btn btn-warning text-white">Reset</button>
                        </div>
                        <!--end::Footer-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>
<style>
    #preview {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 10px;
    }

    .preview-box {
        position: relative;
        display: inline-block;
    }

    .preview-img {
        width: 120px;
        height: 120px;
        object-fit: cover;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .remove-btn {
        position: absolute;
        top: -8px;
        right: -8px;
        background: red;
        color: white;
        border: none;
        border-radius: 50%;
        width: 22px;
        height: 22px;
        cursor: pointer;
        font-size: 14px;
        line-height: 20px;
    }
</style>

<?php include('footer.php'); ?>

<script>
    document.addEventListener("click", e => {
        if (e.target.tagName === "BUTTON" && e.target.textContent.trim() === "×") {
            e.target.parentElement.remove(); // delete the wrapper div
        }
    });
    const input = document.getElementById("gallery_images"),
        preview = document.getElementById("preview");

    let files = [];

    const getSize = f => new Promise((res, rej) => {
        const u = URL.createObjectURL(f),
            img = new Image();
        img.onload = () => (URL.revokeObjectURL(u), res(img.naturalWidth));
        img.onerror = () => (URL.revokeObjectURL(u), rej());
        img.src = u;
    });

    const updateFiles = () => {
        const dt = new DataTransfer();
        files.forEach(f => dt.items.add(f));
        input.files = dt.files;
    };

    const render = () => {
        // preview.innerHTML = "";
        files.forEach((f, i) => {
            const box = document.createElement("div");
            box.style.cssText = "position:relative;display:inline-block";
            box.innerHTML = `
      <img src="${URL.createObjectURL(f)}" style="width:120px;height:120px;object-fit:cover;border:1px solid #ccc;border-radius:6px;box-shadow:0 2px 5px rgba(0,0,0,.1)">
      <button type="button" style="position:absolute;top:-8px;right:-8px;background:red;color:#fff;border:none;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:14px;line-height:20px">×</button>
    `;
            box.querySelector("button").onclick = () => (files.splice(i, 1), render(), updateFiles());
            preview.appendChild(box);
        });
    };

    input.addEventListener("change", async () => {
        files = [];
        const raw = [...input.files].filter(f => f.type.startsWith("image/"));
        if (!raw.length) return alert("Please select valid image files.");

        let skipped = 0;
        for (const f of raw)(await getSize(f) >= 1000 ? files.push(f) : skipped++);

        if (!files.length) {
            input.value = "";
            return alert("No valid images (must be ≥1000px width).");
        }
        if (skipped) alert(`Skipped ${skipped} image(s) (width < 1000px).`);

        render();
        updateFiles();
    });
</script>