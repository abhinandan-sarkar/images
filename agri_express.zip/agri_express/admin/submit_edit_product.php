<?php
include('database.php');
if($_SERVER['REQUEST_METHOD']=='POST'){
    echo "Submit Product Php";
    $sql;
    //Form Variables...
    $category;
    $sub_category;
    $product_name;
    $product_price;
    $product_desc;
    $featured_image;
    $availability;
    $gallery_image;
    $special_product;
    $featured_product;

}
?>