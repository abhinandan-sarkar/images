<?php
include 'header.php';
$sql = "
SELECT p.id,
       p.name AS product_name,
       p.price,
       c.category_name,
       sc.name AS sub_category_name,
       p.availability
FROM product p
INNER JOIN category c ON p.category_id = c.id
INNER JOIN sub_category sc ON p.sub_category_id = sc.id";
$result = execute_query($sql);
// var_dump($result->result);



?>






<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Product</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Product</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-info card-outline p-0 rounded-0 ">
                    <!--begin::Header-->

                    <!--end::Header-->
                    <div class="card-header d-flex justify-content-between">
                        <a href="product.php" class="btn btn-sm bg-success text-white">All</a>
                        <?php $i = 65;
                        while ($i != 90): ?>
                            <a href="product.php?query=<?= chr($i); ?>" class="btn btn-sm bg-success text-white"><?= chr($i); ?></a>
                        <?php $i++;
                        endwhile; ?>
                    </div>
                    <div class="card-header border-0 pb-0">

                        <form class="d-flex gap-4" role="search" method="get" action="product.php">
                            <div class=" d-inline-flex align-items-center  " style="text-wrap:nowrap; font-weight:bold;">Product Name</div>
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="query">
                            <button class="btn btn-sm btn-success" type="submit">Search</button>
                        </form>
                    </div>
                    <div class="card card-info card-outline rounded-0">

                        <div class="card rounded-0 border-0 ">
                            <!-- /.card-header -->
                            <div class="card-body card-info card-outline rounded-0  ">
                                <div> </div>
                                <div class="d-flex justify-content-end"><a href="add_product.php" class="btn btn-success mb-2">Add New</a></div>
                                <table class="table table-hover" role="table">
                                    <thead align="center">
                                        <tr>
                                            <th scope="col">Product Name</th>
                                            <th scope="col">Category Name</th>
                                            <th scope="col">Sub Category Name</th>
                                            <th scope="col">Price($)</th>
                                            <th scope="col">Availability</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody align="center">
                                
                                         <?php
                                        if (isset($_GET['query'])) {
                                            $query = $_GET['query'];
                                            $query = $conn->real_escape_string($query) . '%';

                                            $sql = "SELECT p.id,
                                                        p.name AS product_name,
                                                        p.price,
                                                        c.category_name,
                                                        sc.name AS sub_category_name,
                                                        p.availability
                                                    FROM product p
                                                    INNER JOIN category c ON p.category_id = c.id
                                                    INNER JOIN sub_category sc ON p.sub_category_id = sc.id
                                                    WHERE p.name LIKE '$query';
                                                ";
                                                // echo $sql;

                                            $result = mysqli_query($conn, $sql);

                                            if (mysqli_num_rows($result) > 0) {
                                                while ($item = mysqli_fetch_assoc($result)) {
                                                    echo "
                                                    <tr class='align-middle'>
                                                        <td>{$item['product_name']}</td>
                                                        <td>{$item['category_name']}</td>
                                                        <td>{$item['sub_category_name']}</td>
                                                        <td>{$item['price']}</td>
                                                        <td>{$item['availability']}</td>
                                                        <td class=''>
                                                            <a href='edit_product.php?id={$item['id']}' class='btn btn-sm bg-info text-white'>EDIT</a>
                                                            <a href='delete_product.php?id={$item['id']}' class='btn btn-sm bg-danger text-white'>DELETE</a>
                                                        </td>
                                                    </tr>";
                                                }
                                            } else {
                                                echo "<tr><td class='text-danger' colspan='5'>No record found</td></tr>";
                                            }
                                        } else {

                                            $sql = "SELECT p.id,
                                                        p.name AS product_name,
                                                        p.price,
                                                        c.category_name,
                                                        sc.name AS sub_category_name,
                                                        p.availability
                                                    FROM product p
                                                    INNER JOIN category c ON p.category_id = c.id
                                                    INNER JOIN sub_category sc ON p.sub_category_id = sc.id";

                                            $result = mysqli_query($conn, $sql);

                                            while ($item = mysqli_fetch_assoc($result)) {
                                                echo "
                                                 <tr class='align-middle'>
                                                   <td>{$item['product_name']}</td>
                                                      <td>{$item['category_name']}</td>
                                                      <td>{$item['sub_category_name']}</td>
                                                      <td>{$item['price']}</td>
                                                      <td>{$item['availability']}</td>
                                                      <td class=''>
                                                        <a href='edit_product.php?id={$item['id']}' class='btn btn-sm bg-info text-white'>EDIT</a>
                                                        <a href='' class='btn btn-sm bg-danger text-white'>DELETE</a>
                                                    </td>
                                            </tr>";
                                            }
                                        }
                                        ?>
                                        


                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <!-- <div class="card-footer clearfix ">
                                <ul class="pagination pagination-sm m-0 float-end">
                                    <li class="page-item">
                                        <a class="page-link" href="#">«</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">1</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">2</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">3</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">»</a>
                                    </li>
                                </ul>
                            </div> -->
                        </div>

                    </div>


                </div>








                <!-- Spinner -->
                <!-- <div id="spinnerOverlay">
                    <div class="spinner-border text-success" role="status" style="width: 3rem; height: 3rem;">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div> -->

                <script>
                    const form = document.getElementById('productForm');
                    const spinner = document.getElementById('spinnerOverlay');
                    const responseMsg = document.getElementById('responseMsg');

                    form.addEventListener('submit', async function(e) {
                        e.preventDefault();

                        // Show spinner
                        spinner.style.display = 'flex';
                        responseMsg.innerHTML = "";

                        const formData = new FormData(form);

                        try {
                            const res = await fetch("submit.php", {
                                method: "POST",
                                body: formData
                            });

                            const data = await res.text(); // or res.json() if JSON
                            responseMsg.innerHTML = `<div class="alert alert-success">${data}</div>`;
                        } catch (err) {
                            responseMsg.innerHTML = `<div class="alert alert-danger">Error: ${err.message}</div>`;
                        } finally {
                            spinner.style.display = 'none'; // hide spinner
                        }
                    });
                </script>





                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>


<!--end::App Main-->
<?php include('footer.php'); ?>

<!--begin::Script-->
<script>
    setTimeout(() => {
        let flash = document.getElementById('flashMsg');
        if (flash) {
            flash.classList.remove('show');
            flash.classList.add('hide');
            flash.classList.remove('d-flex');
            flash.classList.add('d-none');

        }
    }, 1000);
</script>



<!--end::Script-->

</html>
<?php    //  unset($_SESSION['flash']);  
?>