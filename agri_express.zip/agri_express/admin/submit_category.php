<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'agri');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['category_name']) ?? '';
    $order_number = trim($_POST['order_number']) ?? '';
    $fileName = $_FILES['image']['name'];
    $status = trim($_POST['status']) ?? '';

    if (!isset($fileName)) {
        $_SESSION['flash'] = [
            'type' => 'danger',
            'message' => 'There is Something'
        ];
        header('Location: category.php');
    }

    //image name changing
    $tmpName = $_FILES['image']['tmp_name'];
    echo $tmpName;
    $originalName = pathinfo($fileName, PATHINFO_FILENAME);
    $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $uploadDir = "/images/category_images/";

    // Allowed extensions
    $allowed = ['jpg', 'jpeg', 'png'];
    if (!in_array($ext, $allowed)) {
          $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Image Extension Not Supported'
            ];
        header('Location: add_sub_category.php');
        exit;
    }

    $tname=$name;
    $tname = strtolower($newString = str_replace(" ", "_", $name));
    $category_image_name = "$tname" . "_" . round(microtime(true)) . '.' . $ext;


    $uploadDir = __DIR__ . "/images/category_images/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $target = $uploadDir . $category_image_name;

    $sql = "INSERT INTO `category`( `category_name`, `image`, `order`, `status`, `created_at` ) VALUES ('$name','$category_image_name','$order_number','$status',now())";
    $result = mysqli_query($conn, $sql) or die();
    if ($result) {
        if (move_uploaded_file($tmpName, $target)) {
            echo "File uploaded successfully! " . $target;
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => "Data added successfully!"
            ];
            header('Location: category.php');
            exit;
        } else {
            echo "Failed to move uploaded file. ".$target;

            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Error: Cannot add to database'
            ];
            header('Location: category.php');
            exit;
        }
    }
}
