<!--begin::Footer-->
<footer class="app-footer">
    <!--begin::To the end-->
    <div class="float-end d-none d-sm-inline">Version 2.4.13</div>
    <!--end::To the end-->
    <!--begin::Copyright-->
    <strong>
        Copyright © 2014-2025&nbsp;
        <a href="../index.php" class="text-decoration-none">Agri Express</a>.
    </strong>
    All rights reserved.
    <!--end::Copyright-->
</footer>
<!--end::Footer-->
<div class="sidebar-overlay"></div>
</div>
<!--end::App Wrapper-->
<script src="js/adminlte.js"></script>
<script src="js/script.js"></script>
