<?php
include('database.php');
session_start();
if (!isset($_SESSION['auth_user'])) {
    header("Location: index.php");
    exit();
}
?>

<html lang="en"><!--begin::Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><?php //echo $pageTitle; 
            ?></title>

    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <meta name="color-scheme" content="light dark">
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)">
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)">
    <!--end::Accessibility Meta Tags-->

    <!--begin::Primary Meta Tags-->
    <meta name="title" content="AdminLTE v4 | Dashboard">
    <meta name="author" content="ColorlibHQ">
    <meta name="description" content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS. Fully accessible with WCAG 2.1 AA compliance.">
    <meta name="keywords" content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard, accessible admin panel, WCAG compliant">
    <!--end::Primary Meta Tags-->

    <!--begin::Accessibility Features-->
    <!-- Skip links will be dynamically added by accessibility.js -->
    <meta name="supported-color-schemes" content="light dark">
    <link rel="preload" href="./css/adminlte.css" as="style">
    <!--end::Accessibility Features-->

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css" integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q=" crossorigin="anonymous" media="all" onload="this.media='all'">
    <!--end::Fonts-->

    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css" crossorigin="anonymous">
    <!--end::Third Party Plugin(OverlayScrollbars)-->

    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" crossorigin="anonymous">
    <!--end::Third Party Plugin(Bootstrap Icons)-->

    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="./css/adminlte.css">
    <link rel="stylesheet" href="./css/style.css">
    <!--end::Required Plugin(AdminLTE)-->

    <!-- apexcharts -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.css" integrity="sha256-4MX+61mt9NVvvuPjUWdUdyfZfxSB1/Rf9WtqRHgG5S0=" crossorigin="anonymous">

    <!-- jsvectormap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/jsvectormap@1.5.3/dist/css/jsvectormap.min.css" integrity="sha256-+uGLJmmTKOqBr+2E6KDYs/NRsHxSkONXFHUL0fy2O/4=" crossorigin="anonymous">

    <!--Summer notes-->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote.min.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<!--end::Head-->
<!--begin::Body-->

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary app-loaded" cz-shortcut-listen="true">
    <div class="skip-links"><a href="#main" class="skip-link">Skip to main content</a><a href="#navigation" class="skip-link">Skip to navigation</a></div>
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
        <!--begin::Header-->
        <nav class="app-header navbar navbar-expand bg-body" id="navigation" tabindex="-1" style="background-color:#80c908;">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Start Navbar Links-->
                <ul class="navbar-nav" role="navigation" aria-label="Navigation 1">
                    <li class="nav-item">
                        <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                            <i class="text-white fs-5 bi bi-list"></i>
                        </a>
                    </li>

                </ul>
                <!--end::Start Navbar Links-->

                <!--begin::End Navbar Links-->
                <ul class="navbar-nav ms-auto" role="navigation" aria-label="Navigation 2">
                    <!--begin::Navbar Search-->

                    <!--begin::User Menu Dropdown-->

                    <li class="nav-item  d-flex ">
                        <a href="../index.php" class="nav-link ">
                            <span class="text-white fw-bold  d-md-inline">Go to site</span>
                        </a>
                        <a href="logout.php" class="nav-link ">
                            <span class="text-white fw-bold d-md-inline">Log Out</span>
                        </a>

                    </li>
                    <!--end::User Menu Dropdown-->
                </ul>
                <!--end::End Navbar Links-->
            </div>
            <!--end::Container-->
        </nav>
        <!--end::Header-->
        <!--begin::Sidebar-->
        <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
            <!--begin::Sidebar Brand-->
            <div class="sidebar-brand" style="background-color:#80c908;">
                <!--begin::Brand Link-->
                <a href="#" class="brand-link">
                    <!--begin::Brand Image-->
                    <img src="images/user.png" class="rounded-circle shadow" alt="User Image">
                    <!--end::Brand Image-->
                    <!--begin::Brand Text-->
                    <span class="brand-text fw-bold">Admin</span>
                    <!--end::Brand Text-->
                </a>
                <!--end::Brand Link-->
            </div>
            <!--end::Sidebar Brand-->
            <!--begin::Sidebar Wrapper-->
            <div class="sidebar-wrapper" data-overlayscrollbars="host">
                <div class="os-size-observer">
                    <div class="os-size-observer-listener"></div>
                </div>
                <div class="" data-overlayscrollbars-viewport="scrollbarHidden overflowXHidden overflowYHidden" tabindex="-1" style="margin-right: -16px; margin-bottom: -16px; margin-left: 0px; top: -8px; right: auto; left: -8px; width: calc(100% + 16px); padding: 8px;">
                    <div class="os-size-observer">
                        <div class="os-size-observer-listener"></div>
                    </div>
                    <div class="" data-overlayscrollbars-viewport="scrollbarHidden overflowXHidden overflowYScroll" tabindex="-1" style="margin-right: -16px; margin-bottom: -16px; margin-left: 0px; top: -8px; right: auto; left: -8px; width: calc(100% + 16px); padding: 8px;">
                        <nav class="mt-2">
                            <!--begin::Sidebar Menu-->
                            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="navigation" aria-label="Main navigation" data-accordion="false" id="navigation">
                                <!-- Dashbord --->
                                <li class="nav-item">
                                    <a href="dashboard.php" class="nav-link ">
                                        <i class="nav-icon bi bi-speedometer text-white"></i>
                                        <p class="text-white">
                                            Dashboard

                                        </p>
                                    </a>

                                </li>
                                <!-- Pages -->



                                <li class="nav-item  ">
                                    <a href="category.php" class="nav-link">
                                        <i class="nav-icon text-white bi bi-ui-checks-grid"></i>
                                        <p class="text-white">
                                            Category
                                            <!-- <i class="text-white nav-arrow bi bi-chevron-right"></i> -->
                                        </p>
                                    </a>
                                    <!-- <ul class="nav nav-treeview" role="navigation" aria-label="Navigation 4" style="box-sizing: border-box; ">
                                        <li class="nav-item">
                                            <a href="pages.php?id=1" class="nav-link">
                                                <i class="nav-icon bi bi-pencil-square"></i>
                                                <p>Home</p>
                                            </a>
                                        </li>


                                    </ul> -->
                                </li>
                                <!--Sub Category Pages -->
                                <li class="nav-item ">
                                    <a href="sub_category.php" class="nav-link ">
                                        <i class="nav-icon bi bi-grid-fill text-white"></i>
                                        <p class="text-white">
                                            Sub Category

                                        </p>
                                    </a>
                                </li>

                                <!--Product Page -->
                                <li class="nav-item ">
                                    <a href="product.php" class="nav-link ">
                                        <i class="nav-icon bi bi-box text-white"></i>
                                        <p class="text-white">
                                            Product

                                        </p>
                                    </a>
                                </li>


                                <!--Order Page -->
                                <li class="nav-item ">
                                    <a href="order.php" class="nav-link ">
                                        <i class="text-white nav-icon bi bi-cart3"></i>
                                        <p class="text-white">
                                            Order

                                        </p>
                                    </a>
                                </li>

                                <!--Discount Page -->
                                <li class="nav-item ">
                                    <a href="discount.php" class="nav-link ">
                                        <i class="nav-icon bi bi-percent text-white"></i>
                                        <p class="text-white">
                                            Discount

                                        </p>
                                    </a>
                                </li>

                                <!--Customer Page -->
                                <li class="nav-item ">
                                    <a href="customer.php" class="nav-link ">
                                        <i class="text-white nav-icon bi bi-person"></i>
                                        <p class="text-white">
                                            Customer

                                        </p>
                                    </a>
                                </li>

                                <!--Order Page -->
                                <li class="nav-item ">
                                    <a href="settings.php" class="nav-link ">
                                        <i class="nav-icon bi bi-gear-wide text-white"></i>
                                        <p class="text-white">
                                            Settings

                                        </p>
                                    </a>
                                </li>






                            </ul>
                            <!--end::Sidebar Menu-->
                        </nav>
                    </div>
                    <div class="os-scrollbar os-scrollbar-horizontal os-theme-light os-scrollbar-auto-hide os-scrollbar-handle-interactive os-scrollbar-track-interactive os-scrollbar-cornerless os-scrollbar-unusable os-scrollbar-auto-hide-hidden" style="--os-scroll-percent: 0; --os-viewport-percent: 1; --os-scroll-direction: 0;">
                        <div class="os-scrollbar-track">
                            <div class="os-scrollbar-handle"></div>
                        </div>
                    </div>
                    <div class="os-scrollbar os-scrollbar-vertical os-theme-light os-scrollbar-auto-hide os-scrollbar-handle-interactive os-scrollbar-track-interactive os-scrollbar-visible os-scrollbar-cornerless os-scrollbar-auto-hide-hidden" style="--os-scroll-percent: 0; --os-viewport-percent: 0.1934; --os-scroll-direction: 0;">
                        <div class="os-scrollbar-track">
                            <div class="os-scrollbar-handle"></div>
                        </div>
                    </div>
                </div>
                <div class="os-scrollbar os-scrollbar-horizontal os-theme-light os-scrollbar-auto-hide os-scrollbar-handle-interactive os-scrollbar-track-interactive os-scrollbar-cornerless os-scrollbar-unusable os-scrollbar-auto-hide-hidden" style="--os-scroll-percent: 0; --os-viewport-percent: 1; --os-scroll-direction: 0;">
                    <div class="os-scrollbar-track">
                        <div class="os-scrollbar-handle"></div>
                    </div>
                </div>
                <div class="os-scrollbar os-scrollbar-vertical os-theme-light os-scrollbar-auto-hide os-scrollbar-handle-interactive os-scrollbar-track-interactive os-scrollbar-cornerless os-scrollbar-unusable os-scrollbar-auto-hide-hidden" style="--os-scroll-percent: 0; --os-viewport-percent: 1; --os-scroll-direction: 0;">
                    <div class="os-scrollbar-track">
                        <div class="os-scrollbar-handle"></div>
                    </div>
                </div>
            </div>
            <!--end::Sidebar Wrapper-->
        </aside>
        <!--end::Sidebar-->