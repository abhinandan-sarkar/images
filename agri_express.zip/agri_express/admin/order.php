<?php
include 'header.php';
?>

<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Order</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Order</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-info card-outline p-0 rounded-0 ">
                    <!--begin::Header-->

                    <!--end::Header-->
                    <div class="card-header border-0 pb-0">

                        <form class="d-flex gap-4" role="search" method="get" action="images.php">
                            <div class=" d-inline-flex align-items-center  " style="text-wrap:nowrap; font-weight:bold;">Order Id</div>
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="query">
                            <button class="btn btn-sm btn-success" type="submit">Search</button>
                        </form>
                    </div>
                    <div class="card card-info card-outline  rounded-0">

                        <div class="card rounded-0 border-0 ">
                            <!-- /.card-header -->
                            <div class="card-body card-info card-outline rounded-0 ">

                                <table class="table table-hover" role="table">
                                    <thead align="center">
                                        <tr>
                                            <th scope="col">Order Id</th>
                                            <th scope="col">Deliver To</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">Price($)</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Who Ordered</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody align="center">
                                        <tr class="align-middle">
                                            <td>89</td>
                                            <td>Bolpur kashimbazar ,Bolpur birbhum </td>
                                            <td>20-Jul-21</td>
                                            <td>9.7</td>
                                            <td>Processing</td>
                                            <td>Abhinandan</td>
                                            <td class="">
                                                <div class="d-flex justify-content-center gap-3">
                                                    <a href="edit_order.php" class="btn btn-sm bg-info text-white">VIEW/EDIT</a>
                                                    <a href="#" class=" btn btn-sm bg-warning text-white">CANCEL</a>
                                                    <a href="#" class=" btn btn-sm bg-danger text-white">Delete</a>
                                                </div>

                                            </td>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer clearfix ">
                                <ul class="pagination pagination-sm m-0 float-end">
                                    <li class="page-item">
                                        <a class="page-link" href="#">«</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">1</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">2</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">3</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">»</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>


                </div>













                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>


<!--end::App Main-->
<?php include('footer.php'); ?>

<!--begin::Script-->
<script>
    setTimeout(() => {
        let flash = document.getElementById('flashMsg');
        if (flash) {
            flash.classList.remove('show');
            flash.classList.add('hide');
            flash.classList.remove('d-flex');
            flash.classList.add('d-none');

        }
    }, 1000);
</script>



<!--end::Script-->

</html>
<?php    //  unset($_SESSION['flash']);  
?>