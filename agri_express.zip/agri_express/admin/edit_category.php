<?php
include('header.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $id = $conn->real_escape_string($id);
}
$sql = "SELECT `id`, `category_name`, `image`, `order`, `status` FROM `category` WHERE id=$id ";
$result = execute_query($sql);
// var_dump($result)

?>
<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Edit Category</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="category.php">Category</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add Category</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-primary card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Category Details</div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->

                    <form id="image_form" action="submit_edit_category.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="category_id" value="<?=$result->row['id'] ?>">

                        <table style="width:100%; border-collapse:collapse;" class="mt-4">
                            <tr>
                                <td style="padding:10px; vertical-align:top;">
                                    <label for="image_nickname" class="form-label">Name <span style="color:red;font-size:20px;">*</span></label>

                                </td>
                                <td style="padding:10px; vertical-align:top;">
                                    <input type="text" class="form-control" id="image_nickname" placeholder="Image Name" name="category_name" value="<?= $result->row['category_name'] ?>">
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:10px; vertical-align:top;">
                                    <label for="image_page_image_order_number" class="form-label">Order Number</label>

                                </td>
                                <td style="padding:10px; vertical-align:top;">
                                    <input type="number" class="form-control" id="image_page_image_order_number" name="order_number" value="<?= $result->row['order'] ?>">
                                </td>
                            </tr>

                            <tr>
                                <td colspan="" style="padding:10px;">
                                    <label for="image_page_image" class="form-label mb-0">Image </label>

                                </td>
                                <td colspan="" style="padding:10px;">

                                    <div class="image_item_parent mb-2  gap-2 ">
                                        <div class="image_item"><img src="images/category_images/<?= $result->row['image'] ?>" alt=""></div>
                                    </div>
                                    <div><small id="error_msg" class="text-danger d-none">Image Width Should Be &gt; 500px</small></div>
                                    <input type="file" class="form-control" id="category_image" name="image_page_image" value="" accept=".png, .jpg, .jpeg">
                                </td>
                            </tr>

                            <tr>
                                <td style="padding:10px;">
                                    <label for="image_page_image_status" class="form-label">Status</label>

                                </td>
                                <td style="padding:10px;">
                                    <select class="form-select" style="cursor:pointer;" id="image_page_image_status" name="status">
                                        <?php
                                        $options = ["Active", "Inactive"];
                                        foreach ($options as $option_value) {
                                            $selected_attribute = ($option_value == $result->row['status']) ? 'selected="selected"' : '';
                                            echo '<option value="' . htmlspecialchars($option_value) . '" ' . $selected_attribute . '>' . htmlspecialchars($option_value) . '</option>';
                                        }
                                        ?>
                                    </select>
                                </td>
                            </tr>


                        </table>
                        <div class="card-footer text-center d-flex justify-content-center gap-4">
                            <button type="submit" class="btn btn-success text-white">Update</button>
                            <button type="reset" class="btn btn-warning text-white">Reset</button>
                        </div>
                    </form>

                    <!--end::Form-->
                </div>
                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>

<?php include('footer.php'); ?>