<?php
include 'header.php';
$sql = "
SELECT sub_category.name,sub_category.id,sub_category.category_id,sub_category.order, sub_category.status, category.category_name
FROM sub_category
INNER JOIN category
ON sub_category.category_id = category.id";
$category_name = mysqli_query($conn, $sql);
$result = execute_query($sql);

?>



<?php
if (isset($_SESSION['flash'])): ?>
    <script>
        var flashType = "<?php echo $_SESSION['flash']['type']; ?>";
        var flashMessage = "<?php echo $_SESSION['flash']['message']; ?>";
    </script>
    <?php unset($_SESSION['flash']); ?>
<?php endif; ?>



<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Sub Category</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Sub Category</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->
                <div class="card card-info card-outline p-0 rounded-0 ">
                    <!--begin::Header-->

                    <!--end::Header-->
                    <div class="card-header d-flex justify-content-between">
                        <a href="sub_category.php" class="btn btn-sm bg-success text-white">All</a>
                        <?php $i = 65;
                        while ($i != 90): ?>
                            <a href="sub_category.php?query=<?= chr($i); ?>" class="btn btn-sm bg-success text-white"><?= chr($i); ?></a>
                        <?php $i++;
                        endwhile; ?>
                    </div>
                    <div class="card-header border-0 pb-0">

                        <form class="d-flex gap-4" role="search" method="get" action="sub_category.php">
                            <div class=" d-inline-flex align-items-center  " style="text-wrap:nowrap; font-weight:bold;">Sub Category Name</div>
                            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="query">
                            <button class="btn btn-sm btn-success" type="submit">Search</button>
                        </form>
                    </div>
                    <div class="card card-info card-outline   rounded-0">

                        <div class="card rounded-0 border-0 ">
                            <!-- /.card-header -->
                            <div class="card-body card-info card-outline rounded-0 ">
                                <div> </div>
                                <div class="d-flex justify-content-end"><a href="add_sub_category.php" class="btn btn-success mb-2">Add New</a></div>
                                <table class="table table-hover" role="table">
                                    <thead align="center">
                                        <tr>
                                            <th scope="col">Sub Category Name</th>
                                            <th scope="col">Order</th>
                                            <th scope="col">Parent Category</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody align="center">
                                        <?php
                                        if (isset($_GET['query'])) {
                                            $query = $_GET['query'];
                                            $query = $conn->real_escape_string($query) . '%';

                                            $sql = "SELECT sub_category.name,
                                                    sub_category.id,
                                                    sub_category.category_id,
                                                    sub_category.order,
                                                    sub_category.status,
                                                    category.category_name
                                                FROM sub_category
                                                INNER JOIN category ON sub_category.category_id = category.id
                                                WHERE sub_category.name LIKE '$query';
                                                ";
                                                // echo $sql;

                                            $result = mysqli_query($conn, $sql);

                                            if (mysqli_num_rows($result) > 0) {
                                                while ($item = mysqli_fetch_assoc($result)) {
                                                    echo "
                                                    <tr class='align-middle'>
                                                    <td>{$item['name']}</td>
                                                      <td>{$item['order']}</td>
                                                      <td>{$item['category_name']}</td>
                                                      <td>{$item['status']}</td>
                                                      <td class=''>
                                                      <a href='edit_sub_category.php?id={$item['id']}' class='btn btn-sm bg-info text-white'>EDIT</a>
                                                    <a href='' class='btn btn-sm bg-danger text-white'>DELETE</a>
                                                    </td>
                                                    </tr>
                                            ";
                                                }
                                            } else {
                                                echo "<tr><td class='text-danger' colspan='5'>No record found</td></tr>";
                                            }
                                        } else {

                                            $sql = "SELECT sub_category.name,sub_category.id,sub_category.category_id,
                                                    sub_category.order, sub_category.status, category.category_name
                                                    FROM sub_category
                                                    INNER JOIN category
                                                    ON sub_category.category_id = category.id";

                                            $result = mysqli_query($conn, $sql);

                                            while ($item = mysqli_fetch_assoc($result)) {
                                                echo "
                                                 <tr class='align-middle'>
                                                    <td>{$item['name']}</td>
                                                      <td>{$item['order']}</td>
                                                      <td>{$item['category_name']}</td>
                                                      <td>{$item['status']}</td>
                                                      <td class=''>
                                                      <a href='edit_sub_category.php?id={$item['id']}' class='btn btn-sm bg-info text-white'>EDIT</a>
                                                      <a href='' class='btn btn-sm bg-danger text-white'>DELETE</a>
                                                    </td>
                                            </tr>";
                                            }
                                        }
                                        ?>





                                    </tbody>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <!-- <div class="card-footer clearfix ">
                                <ul class="pagination pagination-sm m-0 float-end">
                                    <li class="page-item">
                                        <a class="page-link" href="#">«</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">1</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">2</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">3</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">»</a>
                                    </li>
                                </ul>
                            </div> -->
                        </div>

                    </div>


                </div>

                <!--end::Col-->
            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>


<!--end::App Main-->
<?php include('footer.php'); ?>

<!--begin::Script-->


<script>
    $(function() {
        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            height: 80,
        });

        if (typeof flashType !== 'undefined' && typeof flashMessage !== 'undefined') {
            Toast.fire({
                icon: flashType,
                title: flashMessage,
            });
        }
    });
</script>
<style>
    .swal2-toast {
        padding: 6px !important;
        padding-left: 18px !important;
    }

    .swal2-toast h2:where(.swal2-title) {
        margin: 10px !important;
        padding: 0;
        font-size: 13px !important;
        text-align: initial;
        line-height: 20px;
        font-family: var(--bs-body-font-family) !important;
    }
</style>


<!--end::Script-->

</html>