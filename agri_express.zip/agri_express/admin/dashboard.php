<?php
include('header.php');
$sql="SELECT COUNT(category.id)as id from category";
$category_data=execute_query($sql);
$sql="SELECT COUNT(sub_category.id)as id from sub_category";
$sub_category_data=execute_query($sql);
$sql="SELECT COUNT(product.id)as id from product";
$product_data=execute_query($sql);



if (isset($_SESSION['flash'])): ?>
    <script>
        var flashType = "<?php echo $_SESSION['flash']['type']; ?>";
        var flashMessage = "<?php echo $_SESSION['flash']['message']; ?>";
    </script>
    <?php unset($_SESSION['flash']); ?>
<?php endif; ?>





<!--begin::App Main-->
<main class="app-main" id="main" tabindex="-1">
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-0">Dashboard</h3>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->
    <!--begin::App Content-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <!--begin::Col-->




                <div class="col-lg-3 col-6">
                    <!--begin::Small Box Widget 3-->
                    <div class="small-box text-bg-warning">
                        <div class="inner ">
                            <div class="d-flex gap-4">
                                <div>
                                    <h3 class="mb-0">
                                       <?= $category_data->row['id'];?> 
                                    </h3>
                                    <p class="mb-0 ">CATEGORY</p>
                                </div>
                                <div class="d-flex align-items-center fs-1 dash-icon"><i class=" bi bi-ui-checks-grid"></i></div>
                            </div>

                            <div class="d-flex justify-content-end"><a href="category.php"><i class="fs-5 fw-bolder text-white bi bi-plus-lg"></i></a></div>
                        </div>


                    </div>
                    <!--end::Small Box Widget 3-->
                </div>
                <!--end::Col-->

                <div class="col-lg-3 col-6">
                    <!--begin::Small Box Widget 3-->
                    <div class="small-box bg-primary">
                        <div class="inner ">
                            <div class="d-flex gap-4">
                                <div>
                                    <h3 class="mb-0">
                                         <?= $sub_category_data->row['id'];?> 
                                    </h3>
                                    <p class="mb-0">SUB-CATEGORY</p>
                                </div>
                                <div class="d-flex align-items-center fs-1 dash-icon"><i class=" bi bi-grid-fill"></i></div>
                            </div>

                            <div class="d-flex justify-content-end"><a href="sub_category.php"><i class="fs-5 fw-bolder text-white bi bi-plus-lg"></i></a></div>
                        </div>


                    </div>
                    <!--end::Small Box Widget 3-->
                </div>
                <!--end::Col-->

                <div class="col-lg-3 col-6">
                    <!--begin::Small Box Widget 3-->
                    <div class="small-box bg-info">
                        <div class="inner ">
                            <div class="d-flex gap-4">
                                <div>
                                    <h3 class="mb-0">
                                         <?= $product_data->row['id'];?> 
                                    </h3>
                                    <p class="mb-0">PRODUCT</p>
                                </div>
                                <div class="d-flex align-items-center fs-1 dash-icon"><i class=" bi bi-box "></i></div>
                            </div>

                            <div class="d-flex justify-content-end"><a href="product.php"><i class="fs-5 fw-bolder text-white bi bi-plus-lg"></i></a></div>
                        </div>


                    </div>
                    <!--end::Small Box Widget 3-->
                </div>
                <!--end::Col-->

                <div class="col-lg-3 col-6">
                    <!--begin::Small Box Widget 3-->
                    <div class="small-box bg-success">
                        <div class="inner ">
                            <div class="d-flex gap-4">
                                <div>
                                    <h3 class="mb-0">
                                        0
                                    </h3>
                                    <p class="mb-0">ORDER</p>
                                </div>
                                <div class="d-flex align-items-center fs-1 dash-icon"><i class=" bi bi-cart3"></i></div>
                            </div>

                            <div class="d-flex justify-content-end"><i class=" fs-5 fw-bolder text-success bi bi-plus-lg"></i></div>
                        </div>


                    </div>
                    <!--end::Small Box Widget 3-->
                </div>
                <!--end::Col-->

                <div class="col-lg-3 col-6">
                    <!--begin::Small Box Widget 3-->
                    <div class="small-box bg-danger">
                        <div class="inner ">
                            <div class="d-flex gap-4">
                                <div>
                                    <h3 class="mb-0">
                                        0
                                    </h3>
                                    <p class="mb-0">CUSTOMER</p>
                                </div>
                                <div class="d-flex align-items-center fs-1 dash-icon"><i class="bi bi-person"></i></div>
                            </div>

                            <div class="d-flex justify-content-end"><i class=" fs-5 fw-bolder text-danger bi bi-plus-lg"></i></div>
                        </div>


                    </div>
                    <!--end::Small Box Widget 3-->
                </div>
                <!--end::Col-->


                <div class="col-lg-3 col-6">
                    <!--begin::Small Box Widget 3-->
                    <div class="small-box bg-warning">
                        <div class="inner ">
                            <div class="d-flex gap-4">
                                <div>
                                    <h3 class="mb-0">
                                        0
                                    </h3>
                                    <p class="mb-0 text-nowrap">DISCOUNT COUPON</p>
                                </div>
                                <div class="d-flex align-items-center fs-1 dash-icon"><i class="bi bi-percent"></i></div>
                            </div>

                            <div class="d-flex justify-content-end"><a href="discount.php"><i class="fs-5 fw-bolder text-white bi bi-plus-lg"></i></a></div>
                        </div>


                    </div>
                    <!--end::Small Box Widget 3-->
                </div>
                <!--end::Col-->




            </div>
            <!--end::Row-->
            <!--begin::Row-->

            <!-- /.row (main row) -->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>



<script>
    $(function() {
        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            height: 80,
        });

        if (typeof flashType !== 'undefined' && typeof flashMessage !== 'undefined') {
            Toast.fire({
                icon: flashType,
                title: flashMessage,
            });
        }
    });
</script>
<style>
    .swal2-toast {
        padding: 6px !important;
        padding-left: 18px !important;
    }

    .swal2-toast h2:where(.swal2-title) {
        margin: 10px !important;
        padding: 0;
        font-size: 13px !important;
        text-align: initial;
        line-height: 20px;
        font-family: var(--bs-body-font-family) !important;
    }
</style>

<!--end::App Main-->
<?php include('footer.php'); ?>

<!--begin::Script-->
<!--end::Script-->


</html>

