<?php
if($_SERVER['REQUEST_METHOD']=="POST"){
    $id=isset($_POST['category_id'])?trim($_POST['category_id']):'';
    $category_name=isset($_POST['category_name'])?trim($_POST['category_name']):'';
    $order=isset($_POST['order_number'])?trim($_POST['order_number']):'';;
    $category_image=isset($_FILES['category_image'])?$_FILES['category_image']:'';
    $status=isset($_POST['status'])?trim($_POST['status']):'';

    if(empty($id) || empty($category_name)){
        header('Location: category.php');

    }

    var_dump($id);
    var_dump($category_name);
    var_dump($order);
    var_dump($status);
    var_dump($category_image);

}
?>