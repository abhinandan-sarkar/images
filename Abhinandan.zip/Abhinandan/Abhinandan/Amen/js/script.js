//========== utility function===========

function queryAll(selector){return document.querySelectorAll(selector);}

function query(selector){return document.querySelector(selector);}

//========== Top Banner Section=======

let slideItems=queryAll('.item-box');
let sliderHolder=query('.slide-holder');
sliderHolder.style.transition = "0ms";
let neetSlideElement = sliderHolder.innerHTML;

let firstSlideHTML = slideItems[0].outerHTML;
let lastSlideHTML = slideItems[slideItems.length - 1].outerHTML;

sliderHolder.innerHTML = lastSlideHTML + neetSlideElement + firstSlideHTML;

let newSliderHolder = query('.slide-holder');
let newSliderHolderHTML = newSliderHolder.innerHTML;
let finalSliderItems = queryAll('.item-box');

for (let i = 0; i < finalSliderItems.length; i++) {
    finalSliderItems[i].style.display = "none";
}

finalSliderItems[0].style.display = "flex";
finalSliderItems[1].style.display = "flex";
finalSliderItems[2].style.display = "flex";

let indicatorHolders = query('.indicator-div');

let indicatorHTML = '<div class="indicator" onclick="callSlide(';
let indicatorHTML2 = ')"><div></div></div>';


let indHolderinnerHtml = "";
for (let i = 0; i < slideItems.length; i++) {
    indHolderinnerHtml += indicatorHTML + i + indicatorHTML2;
}
indicatorHolders.innerHTML = indHolderinnerHtml;

let indicator = document.querySelectorAll(".indicator");
indicator[0].children[0].setAttribute('class','dot');


// Adjust crossline and indicator section width to match indicators
let crossLine = query('#crossline');
let indicatorSection = query('.indicator-wrapper');
crossLine.style.width = (indicatorHolders.offsetWidth-2) + "px";


let totalSlide = queryAll(".item-box");


let slideIndex = 2;
let slideDuration = 1000;        // Animation duration
let animateInterval = 5000;      // Time between slides


sliderHolder.style.transform = "translateX(-958px)";


//===============Next Slide Function

function nextSlide() {
    sliderHolder.style.transition = slideDuration + "ms";
    sliderHolder.style.transform = "translateX(-1916px)"; // Move to next slide

    // Reset all indicators
    for (let i = 0; i < slideItems.length; i++) {
        indicator[i].children[0].removeAttribute('class','dot');
        indicator[i].children[0].style.transition = slideDuration + "ms";
    }

    // Activate next indicator or wrap to first
    if (slideIndex == slideItems.length + 1) {
         indicator[0].children[0].setAttribute('class','dot');
    } else {
        indicator[slideIndex - 1].children[0].setAttribute('class','dot');
    }

    setTimeout(() => {
        // Instantly jump back to real slide set without animation
        sliderHolder.style.transition = "0ms";

        // Hide all slides
        for (let i = 0; i < finalSliderItems.length; i++) {
            finalSliderItems[i].style.display = "none";
        }

        // If reached cloned last slide, reset back to original first 3
        if (slideIndex == slideItems.length + 1) {
            finalSliderItems[0].style.display = "flex";
            finalSliderItems[1].style.display = "flex";
            finalSliderItems[2].style.display = "flex";
            sliderHolder.style.transform = "translateX(-958px)";
            slideIndex = 2;
        } else {
            // Display next 3 slides
            finalSliderItems[slideIndex - 1].style.display = "flex";
            finalSliderItems[slideIndex].style.display = "flex";
            finalSliderItems[slideIndex + 1].style.display = "flex";
            sliderHolder.style.transform = "translateX(-958px)";
            slideIndex++;
        }
    }, slideDuration);
}


//================PREVIOUS SLIDE FUNCTION

function prevSlide() {
    if (slideIndex == 2) {
        // If at first real slide, jump to last cloned set
        sliderHolder.style.transition = "0ms";

        // Hide all
        for (let i = 0; i < finalSliderItems.length; i++) {
            finalSliderItems[i].style.display = "none";
        }

        // Update indicators
        for (let i = 0; i < slideItems.length; i++) {
            indicator[i].children[0].removeAttribute('class','dot');
            indicator[i].style.transition = slideDuration + "ms";
        }
        indicator[slideItems.length - 1].children[0].setAttribute('class','dot');

        // Display first 2 slides and transition to the last visible set
        finalSliderItems[0].style.display = "flex";
        finalSliderItems[1].style.display = "flex";
        sliderHolder.style.transform = "translateX(-958px)";
        sliderHolder.style.transition = slideDuration + "ms";
        sliderHolder.style.transform = "translateX(0px)";

        setTimeout(() => {
            sliderHolder.style.transition = "0ms";
            for (let i = 0; i < finalSliderItems.length; i++) {
                finalSliderItems[i].style.display = "none";
            }
            // Show last 3 slides
            finalSliderItems[finalSliderItems.length - 1].style.display = "flex";
            finalSliderItems[finalSliderItems.length - 2].style.display = "flex";
            finalSliderItems[finalSliderItems.length - 3].style.display = "flex";
            sliderHolder.style.transform = "translateX(-958px)";
            slideIndex = slideItems.length + 1;
        }, slideDuration);
    } else {
        // Normal previous slide
        sliderHolder.style.transition = slideDuration + "ms";
        sliderHolder.style.transform = "translateX(0px)";
        for (let i = 0; i < slideItems.length; i++) {
            indicator[i].children[0].removeAttribute('class','dot');
            indicator[i].style.transition = slideDuration + "ms";
        }
        indicator[slideIndex - 3].children[0].setAttribute('class','dot');

        setTimeout(() => {
            sliderHolder.style.transition = "0ms";
            for (let i = 0; i < finalSliderItems.length; i++) {
                finalSliderItems[i].style.display = "none";
            }
            finalSliderItems[slideIndex - 1].style.display = "flex";
            finalSliderItems[slideIndex - 2].style.display = "flex";
            finalSliderItems[slideIndex - 3].style.display = "flex";
            sliderHolder.style.transform = "translateX(-958px)";
            slideIndex -= 1;
        }, slideDuration);
    }
}

//===================INDICATOR CLICK FUNCTION

function callSlide(call) {
    clearInterval(amimateClk);  // Stop auto slide
    let activeInd = slideIndex - 2;

    // Update indicator styles
    for (let i = 0; i < slideItems.length; i++) {
        indicator[i].children[0].removeAttribute('class','dot');
        indicator[i].style.transition = slideDuration + "ms";
    }
    indicator[call].children[0].setAttribute('class','dot');

    if (call > activeInd) {
        // Slide forward
        let callindex = call + 1;
        let currentindex = slideIndex - 1;

        for (let i = 0; i < finalSliderItems.length; i++) {
            finalSliderItems[i].style.display = "none";
        }

        finalSliderItems[currentindex - 1].style.display = "flex";
        finalSliderItems[currentindex].style.display = "flex";
        finalSliderItems[callindex].style.display = "flex";

        sliderHolder.style.transition = slideDuration + "ms";
        sliderHolder.style.transform = "translateX(-1917px)";

        setTimeout(() => {
            sliderHolder.style.transition = "0ms";
            for (let i = 0; i < finalSliderItems.length; i++) {
                finalSliderItems[i].style.display = "none";
            }
            finalSliderItems[callindex - 1].style.display = "flex";
            finalSliderItems[callindex].style.display = "flex";
            finalSliderItems[callindex + 1].style.display = "flex";
            sliderHolder.style.transform = "translateX(-958px)";
            slideIndex = callindex + 1;
        }, slideDuration);
    } else if (call < activeInd) {
        // Slide backward
        let actualHTML = sliderHolder.innerHTML;
        let ii = 0;
        while (ii < slideItems.length) {
            for (let i = 0; i < slideItems.length; i++) {
                slideItems[i].style.display = "none";
            }
            finalSliderItems =  queryAll(".item-box");
            finalSliderItems[slideIndex - 2].style.display = "flex";
            finalSliderItems[slideIndex - 1].style.display = "flex";
            finalSliderItems[slideIndex].style.display = "flex";
            indicator[ii].children[0].removeAttribute('class','dot');
            ii++;
        }

        indicator[call].children[0].setAttribute('class','dot');

        // Load clicked slide content
        let calledSlideHTML = slideItems[call].innerHTML;
        finalSliderItems[slideIndex].style.display = "flex";
        finalSliderItems[slideIndex].innerHTML = calledSlideHTML;

        sliderHolder.style.transition = slideDuration + "ms";
        sliderHolder.style.transform = "translateX(-1917px)";

        setTimeout(function () {
            // Restore previous HTML and reset display
            sliderHolder.innerHTML = actualHTML;
            finalSliderItems = queryAll(".item-box");
            for (let i = 0; i < finalSliderItems.length; i++) {
                finalSliderItems[i].style.display = "none";
                finalSliderItems[call].style.display = "flex";
                finalSliderItems[call + 1].style.display = "flex";
                finalSliderItems[call + 2].style.display = "flex";
            }

            sliderHolder.style.transition = "0ms";
            sliderHolder.style.transform = "translateX(-958px)";
            slideIndex = call + 2;
        }, slideDuration);
    }
}

// Auto Slide Pause on Hover
// Start auto animation
let amimateClk = setInterval(nextSlide, animateInterval);

// Pause on hover
let sliderMainContainer = query('.slider');
sliderMainContainer.addEventListener("mouseenter", () => {
    clearInterval(amimateClk);
});
sliderMainContainer.addEventListener("mouseleave", () => {
    amimateClk = setInterval(nextSlide, animateInterval);
});

// Pause on indicator hover
for (let i = 0; i < slideItems.length; i++) {
    indicator[i].addEventListener("mouseenter", () => {
        clearInterval(amimateClk);
    });
    indicator[i].addEventListener("mouseleave", () => {
        amimateClk = setInterval(nextSlide, animateInterval);
    });
}


//=========================BOTTOM SPONSORS SLIDER
let logoWrapper=query('.image-holder-wrapper');
let logoHolder=query('.image-holder'); 
let slideNextBtn =query('.nxt') ;
let slidePrevBtn = query('.pre');

let offsetY = 0;          
let setOffsetY = 0;        
let offsetErr = 0;        
let imagePerView = 5;     
let imageWidth = 80;   

let images = queryAll('.sponsor')
let maxIndex = Math.floor(images.length / 5); 
let sliderIndex = 1;     
var yy = 0;
var eyy=0;

let imageHolder =query('.image-holder-wrapper'); 


slidePrevBtn.style.opacity = "0.2";
slidePrevBtn.style.cursor = "default";


imageHolder.style.transition = "1.5s";
imageHolder.style.width = ((images.length * imageWidth) + ((images.length - 1) * offsetErr)) + "px";

// Set horizontal offset per step
if (Math.floor(images.length / 5) > 1) {
    yy = 5 * (imageWidth + offsetErr);
}

// Remaining pixels for last slide
if ((images.length % 5) > 0) {
    var a = (images.length % 5) * (imageWidth + offsetErr);
    
}
eyy=a;

var reachEnd = false;  // Flag to detect last slide

//==============Sponsor Next and Previous Functions

function nextSpons() {
    if (sliderIndex == maxIndex) {
        // At last main slide
        if (!reachEnd) {
	    console.log('else runing');
            setOffsetY += eyy;
            imageHolder.style.transform = 'translateX(-' + setOffsetY + 'px)';
            sliderIndex++;
            reachEnd = true;
           
        }
    } else if (sliderIndex < maxIndex) {
	console.log('else runing');
        setOffsetY += yy;
        imageHolder.style.transform = 'translateX(-' + setOffsetY + 'px)';
        ++sliderIndex;
      
    }
	checkArrow(sliderIndex);
}

function prevSpons() {
    if (sliderIndex == 2) {
        if (reachEnd) {
            setOffsetY -= eyy;
        } else {
            setOffsetY -= yy;
        }
        imageHolder.style.transform = 'translateX(-' + setOffsetY + 'px)';
        sliderIndex--;
        reachEnd = false;
        slidePrevBtn.style.opacity = "0.2";
        slidePrevBtn.style.cursor = "default";
    } else if (sliderIndex > 2) {
        setOffsetY -= yy;
        imageHolder.style.transform = 'translateX(-' + setOffsetY + 'px)';
        sliderIndex--;
     
    }
	checkArrow(sliderIndex);
}

 function checkArrow(currentIndex){
		//alert(currentIndex)
		if(currentIndex=="1"){
			  slideNextBtn.style.opacity = "1";
        		  slideNextBtn.style.cursor = "pointer";
 			  slidePrevBtn.style.opacity = "0.2";
		          slidePrevBtn.style.cursor = "default";
			  slidePrevBtn.style.pointerEvents= 'none';
			  
		
		}else if(currentIndex==(maxIndex)){
			  slideNextBtn.style.opacity =  "0.2";
        		  slideNextBtn.style.cursor ="default";
 			  slidePrevBtn.style.opacity = "1";
		          slidePrevBtn.style.cursor = "pointer";
			  slideNextBtn.style.pointerEvents= 'none';
		}else{
			  slideNextBtn.style.opacity =   "1";
        		  slideNextBtn.style.cursor ="pointer";
 			  slidePrevBtn.style.opacity =  "1";
		          slidePrevBtn.style.cursor = "pointer";
	                  slideNextBtn.style.pointerEvents= 'auto';
			  slidePrevBtn.style.pointerEvents= 'auto';
		}
}
