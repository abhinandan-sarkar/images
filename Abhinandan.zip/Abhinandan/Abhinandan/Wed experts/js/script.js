let query=(selector)=>document.querySelector(selector);
let queryAll=(selector)=>document.querySelectorAll(selector);
let vendor=query('#vendor');
let state=query('#state');
let city=query('#city');
let vendorError=query('.VendorError');
let stateError=query('.StateError');
let cityError=query('.cityError');
let valid=false;
let cityList={

	"Bihar":["Patna", "Gaya", "Bhagalpur","Muzaffarpur"],
	"Odisha":["Bhubaneswar", "Puri", "Cuttack","Konark"],
	"Karnataka":["Bengaluru","Kolar","Mysuru"],
	"West Bengal":["Kolkata", "Asansol", "Siliguri","Durgapur"]
}
let cityValid=false,stateValid=false,vendorValid=false;
//======================= initial stage=====


city.style.cursor='not-allowed';
city.disabled = true;



function validateForm(){
let valid=checkValidation()
if(valid){
	alert("congratulation!");
	return true; // Allow form submission
}else{
	return false;
}

	
}

vendor.addEventListener("change",()=>{

if(vendor.value==""){
	vendor.focus();
	vendorError.innerText="*Please enter the value";
	vendor.style.border="1px solid red";
	vendorValid=false;
}else{
	vendorError.innerText=""
	vendor.style.border="1px solid #111";
	vendorValid=true;
}
});


state.addEventListener("change",()=>{

if(state.value==""){
	state.focus();
	stateError.innerText="*Please enter the value"
	stateValid=false;
	city.style.cursor='not-allowed';
	city.disabled = true;
}else{
	stateError.innerText=""
	valid=true;
	city.style.cursor='pointer';
	city.disabled = false;
	stateValid=true;
	genCity(state.value)
	
	
}
});




city.addEventListener("change",()=>{

if(city.value==""){
	city.focus();
	city.innerText="*Please enter the value"
	cityValid=false;
}else{
	stateError.innerText="";
	cityValid=true;
}
 	
});


function genCity(value){

	let html=`<option value="">-- Choose A Service --</option>`;
	let objLength=cityList[value].length;
for(let i=0;i<objLength;i++){
	html+=`<option value="${cityList[value][i]}">${cityList[value][i]}</option>`
	
}
	city.innerHTML=html;
}

function checkValidation(){
	if((cityValid && stateValid) && vendorValid){return true}
}

