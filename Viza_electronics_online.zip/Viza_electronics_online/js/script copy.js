//================DOM  SELECTOR===========

let query = (sel) => document.querySelector(sel);
let queryAll = (sel) => document.querySelectorAll(sel);

//================VARIABLE PART===========

let bannerImg = queryAll('.banner');
let video = query('video');
let index = 0;
let videoPlyBtn = query('.playBtnImg img');
let smallPauseBtn = query('.pause');
let smallPlayBtn = query('.play');
let currentTime = query('.currentTime');
let totalDuration = query('.durationTime');
let range = query('#range');
let lines = queryAll('.line');
let seekingBox = query('.seeking');
let articalBody = query('.artical-body');
let bigArtical = queryAll('.artical-big-item');
let arrowBig = queryAll('.arrow_big');
let fullScreenBtn = query('.full-screen img');
let videoContainer = query('.video-container');
let wrapper = query('#wrapper');
let forcePause = false;
let cursorTimeout;
let centerIconTimeout;
let hideControlsTimer;
const fullscreenBtnX = query('.full_screen');
let controlsWrapper = query('.full-video-control');
let videoWrapper = query('.video-wrapper');
let scrollYPosition = 0;
let playItemValue;
let videoOverlay = query('.video-overlay');
let videoPlayingInterval;
let videoThubnail = query('.thubnail-image');
let ThubnailShowTimer;
let ThubnailHideTimer;
let firstTimeVideoPlay = false;
let fullScreenBtnHoverTimer;
let suppressIconHide = false;
let wasSeekbarClickedFirstTime = false;

//===============INITIAL PROCESS==========

bannerImg.forEach((ele, val) => {
	ele.style.display = index === val ? `block` : `none`;
});

articalBody.addEventListener("mouseenter", () => {
	articalBody.style.border = `1px solid #3399cc`;
	articalBody.style.borderTop = `1px solid #cbcbcb`;
});

articalBody.addEventListener("mouseleave", () => {
	articalBody.style.border = `1px solid #cbcbcb`;
});

bigArtical.forEach((ele) => {
	ele.addEventListener("mouseenter", (e) => {
		e.target.style.border = `1px solid #3399cc`;
	});
	ele.addEventListener("mouseleave", (e) => {
		e.target.style.border = `1px solid #cbcbcb`;
	});
});

//============== BANNER ==================

let activeIndex = 0;
let intervalTimer = 4000;
let blinkInterval;

function blinkFn() {
	bannerImg[activeIndex].classList.remove('blink');
	activeIndex = (activeIndex + 1) % bannerImg.length;
	bannerImg[activeIndex].classList.add('blink');

	bannerImg.forEach((ele, val) => {
		ele.style.display = activeIndex === val ? `block` : `none`;
	});
}

blinkInterval = setInterval(blinkFn, intervalTimer);

query('.hero-img').addEventListener("mouseenter", () => {
	clearInterval(blinkInterval);
});

query('.hero-img').addEventListener("mouseleave", () => {
	blinkInterval = setInterval(blinkFn, intervalTimer);
});

//============ PLAY PAUSE BUTTON======


//==============VIDEO===========


//============== VOLUME ============== 

//==============SEEK================

//=================FULL SCREEN===========

document.addEventListener('fullscreenchange', () => {
	if (document.fullscreenElement) {
		wrapper.classList.add('fullscreen-mode');
		videoThubnail.classList.add('video-overlay-fullscreen-mode');
		videoOverlay.classList.add('video-overlay-fullscreen-mode');

		fullScreenBtn.style.display = 'none';
	} else {
		wrapper.classList.remove('fullscreen-mode');
		videoThubnail.classList.remove('video-overlay-fullscreen-mode');
		videoOverlay.classList.remove('video-overlay-fullscreen-mode');

		// scrollTo(0, scrollYPosition)
		setTimeout(() => scrollTo(0, scrollYPosition), 60);
		fullScreenBtn.style.display = 'inline-block';
		fullScreenBtn.style.opacity = '0';

	}

	if (!document.fullscreenElement) {
		controlsWrapper.style.opacity = '1';
		controlsWrapper.style.pointerEvents = 'auto';
		clearTimeout(hideControlsTimer);
	} else {
		showControls();
		hideControls();
	}

	fullscreenBtnX.style.display = (document.fullscreenElement) ? 'flex' : 'none';
});

fullScreenBtn.onclick = toggleFullscreen;
fullscreenBtnX.onclick = toggleFullscreen;
videoThubnail.onclick = togglePlayPause;
videoOverlay.onclick = togglePlayPause

//=================BIG CONTROLLER======

videoWrapper.addEventListener('mousemove', () => {
	if (!document.fullscreenElement) return;
	showControls();
	hideControls();
});

videoWrapper.addEventListener('mouseenter', () => {
	if (!document.fullscreenElement) return;
	showControls();
	hideControls();
});

videoWrapper.addEventListener('mouseleave', () => {
	if (!document.fullscreenElement) return;
	clearTimeout(hideControlsTimer);
	controlsWrapper.style.opacity = '0';
	controlsWrapper.style.pointerEvents = 'none';
});

window.addEventListener('load', () => {
	controlsWrapper.style.opacity = '1';
	controlsWrapper.style.pointerEvents = 'auto';
});



//======================Youtube Player

var tag = document.createElement('script');
tag.src = "https://www.youtube.com/iframe_api";
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

let durationTimer = null;

function onYouTubeIframeAPIReady() {
	player = new YT.Player('video', {
		height: '190',
		width: '290',
		videoId: '9Nm9tU93BZo',
		playerVars: {
			'controls': 0,
			'disablekb': 1,
			'modestbranding': 1,
			'rel': 0,
			'fs': 0,
			'iv_load_policy': 3,
			'playsinline': 1,
			'enablejsapi': 1
		},
		events: {
			'onReady': onPlayerReady,
			'onStateChange': onPlayerStateChange

		}
	});
}



//=================WHEN READY=================
function onPlayerReady() {
	setupInitialVolume();
	setupSeekControl();
	setupVolumeControl();
	setupPlayPauseButtons();
	setupFullscreenButtons();
	setupOverlayHover();
	showTotalDuration();
	range.style.width = `0%`;
}

//=================PLAYBACK STATE=================


function onPlayerStateChange(event) {
	const state = player.getPlayerState();

	if (state === YT.PlayerState.PLAYING) {
		if (!suppressAutoTimer) {
			durationTimer = setInterval(() => {
				const current = player.getCurrentTime();
				const total = player.getDuration();
				currentTime.textContent = formatTime(current);
				range.style.width = `${(current / total) * 100}%`;
			}, 500);
		}

		if (!suppressIconHide) {
			resetCursorHideTimer();
			resetCenterHideTimer();
		}

	} else if (state === YT.PlayerState.PAUSED) {
		clearInterval(durationTimer);
		clearTimeout(centerIconTimeout);
		clearTimeout(hideControlsTimer);
		controlsWrapper.style.opacity = '1';
		controlsWrapper.style.pointerEvents = 'auto';
		coursorBehavior();
		videoPlyBtn.style.cursor = 'pointer';
		setThumbnailVisibility(true);
		showCenterIcon(false);

	} else if (state === YT.PlayerState.ENDED) {
		clearInterval(durationTimer);
		range.style.width = "100%";
		currentTime.textContent = formatTime(player.getDuration());
		showCenterIcon(false);
		setThumbnailVisibility(true);
	}
}



//=================TOGGLE PLAY PAUSE=================
function togglePlayPause() {
	const state = player.getPlayerState();

	if (state === YT.PlayerState.PLAYING) {
		player.pauseVideo();
		setThumbnailVisibility(true);
		showCenterIcon(false);
		return;
	}
	if (!firstTimeVideoPlay && wasSeekbarClickedFirstTime) {
		firstTimeVideoPlay = true;
		player.playVideo();
		player.mute()
		setTimeout(() => {
			player.unMute();
			setThumbnailVisibility(false);
			hideCenterImage();
			showCenterIcon(true);
			hideCenterImage();
		}, 4000)
		console.log('first seekbar play')
		return;
	}

	if (!firstTimeVideoPlay) {
		firstTimeVideoPlay = true;
		suppressAutoTimer = true;
		suppressIconHide = true;

		player.playVideo();
		player.mute();
		clearInterval(durationTimer);

		setTimeout(() => {
			player.seekTo(0, true);
			player.playVideo();
			player.unMute();
			suppressAutoTimer = false;

			durationTimer = setInterval(() => {
				const current = player.getCurrentTime();
				const total = player.getDuration();
				currentTime.textContent = formatTime(current);
				range.style.width = `${(current / total) * 100}%`;
			}, 500);

			setThumbnailVisibility(false);

			setTimeout(() => {
				suppressIconHide = false;
				hideCenterImage();
				showCenterIcon(true);
			}, 100);

			console.log('first time play')
		}, 6000);

		return;
	} else {
		player.playVideo();
		setTimeout(() => setThumbnailVisibility(false), 700);
		showCenterIcon(true);
		hideCenterImage();
		console.log('else play....')
	}
}

//=================VOLUME UI UPDATE=================
function updateVolumeLines(index) {
	lines.forEach((line, i) => {
		line.style.backgroundColor = i <= index ? "#fff" : "#333";
	});
	if (index === 0) {
		lines.forEach(line => line.style.backgroundColor = "#333");
	}
}


//=====================CUSTOM FUNCTIONS============

function formatTime(seconds) {
	const min = Math.floor(seconds / 60);
	const sec = Math.floor(seconds % 60);
	return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
}

function updatePlayPauseIcon(isPlaying) {
	const playIcon = smallPlayBtn.querySelector('img');
	const bigPlayIcon = query('.playBtnImg img');
	const newSrc = isPlaying ? 'images/pause.svg' : 'images/play_button_small.svg';
	playIcon.src = newSrc;
	bigPlayIcon.src = newSrc;
}

function showControls() {
	if (!document.fullscreenElement) return;
	controlsWrapper.style.opacity = '1';
	controlsWrapper.style.pointerEvents = 'auto';
	videoPlyBtn.style.opacity = '0.6';
	videoPlyBtn.style.cursor = 'pointer';
	clearTimeout(hideControlsTimer);
}

function hideControls() {
	if (!document.fullscreenElement) return;
	hideControlsTimer = setTimeout(() => {
		controlsWrapper.style.opacity = '0';
		controlsWrapper.style.pointerEvents = 'none';
		videoPlyBtn.style.opacity = '0';
		hideCenterImage();

	}, 2000);
}

function toggleFullscreen() {
	if (!document.fullscreenElement) {
		scrollYPosition = scrollYPositionFn();
		setTimeout(() => wrapper.requestFullscreen(), 10);
		//wrapper.requestFullscreen()
	} else {
		document.exitFullscreen();
		setTimeout(() => scrollTo(0, scrollYPosition), 100);
		//scrollTo(0, scrollYPosition)
	}
}




function showCenterIcon(isPlaying) {
	playItemValue = isPlaying;
	clearTimeout(centerIconTimeout);
	updatePlayPauseIcon(isPlaying);
	videoPlyBtn.style.opacity = '0.6';
	videoPlyBtn.style.cursor = 'pointer';
	fullScreenBtn.style.opacity = '0.6';
	fullScreenBtn.style.pointerEvents = 'auto';
}

function hideCenterImage() {
	if (player.getPlayerState() === YT.PlayerState.PAUSED) return;
	videoPlyBtn.style.opacity = '0';
	videoPlyBtn.style.cursor = 'none';
	fullScreenBtn.style.opacity = '0';
	fullScreenBtn.style.cursor = 'default';
	fullScreenBtn.style.pointerEvents = 'none';
}



function mouseEnterFn() {
	if (!document.fullscreenElement) {
		fullScreenBtn.style.opacity = '0.6';
		videoPlyBtn.style.opacity = '0.6';
		fullScreenBtn.style.pointerEvents = 'auto';
		fullScreenBtn.style.cursor = 'pointer';
		videoPlyBtn.style.cursor = 'pointer';
		videoPlyBtn.style.pointerEvents = 'auto';

		hoverHideTimerStart();
	}
}

function hoverHideTimerStart() {
	if (player.getPlayerState() === YT.PlayerState.PLAYING) {
		clearTimeout(fullScreenBtnHoverTimer);
		fullScreenBtnHoverTimer = setTimeout(() => {
			hideCenterImage();
			videoOverlay.style.cursor = 'none';
		}, 2000);
	}
}

function coursorBehavior() {
	videoOverlay.style.cursor = 'default';
}

function resetCursorHideTimer() {
	clearTimeout(cursorTimeout);
	cursorTimeout = setTimeout(() => {
		if (player.getPlayerState() === YT.PlayerState.PLAYING) {
			videoOverlay.style.cursor = 'none';
			videoPlyBtn.style.cursor = 'none';
			fullScreenBtn.style.cursor = 'none';
		}
	}, 2000);
}

function resetCenterHideTimer() {
	clearTimeout(centerIconTimeout);

	if (player.getPlayerState() === YT.PlayerState.PLAYING) {
		centerIconTimeout = setTimeout(() => {
			hideCenterImage();
		}, 2000);
	}
}


function scrollYPositionFn() {
	return window.scrollY;
}

videoOverlay.addEventListener("mouseleave", () => {
	if (!document.fullscreenElement) {
		fullScreenBtn.style.opacity = '0';
		videoPlyBtn.style.opacity = '0';
	}
});




videoPlyBtn.addEventListener("mouseenter", mouseEnterFn);
fullScreenBtn.addEventListener("mouseenter", mouseEnterFn);


videoOverlay.addEventListener("mousemove", (event) => {
	const hoveredElement = document.elementFromPoint(event.clientX, event.clientY);

	if (
		hoveredElement === fullScreenBtn ||
		hoveredElement === videoPlyBtn ||
		fullScreenBtn.contains(hoveredElement) ||
		videoPlyBtn.contains(hoveredElement)
	) {
		videoOverlay.style.cursor = 'pointer';
	} else {
		videoOverlay.style.cursor = 'default';
	}

	const state = player.getPlayerState();
	if (state === YT.PlayerState.PLAYING) {
		showCenterIcon(true);
		resetCursorHideTimer();
		resetCenterHideTimer();
	} else if (state === YT.PlayerState.PAUSED) {
		showCenterIcon(false);
		videoPlyBtn.style.cursor = 'pointer';
		clearTimeout(cursorTimeout);
	}
});


videoThubnail.addEventListener('mouseenter', () => {
	let state = player.getPlayerState();
	if (state === YT.PlayerState.PLAYING) { showCenterIcon(true); }
	if (state === YT.PlayerState.PAUSED) { showCenterIcon(false); }
});

videoThubnail.addEventListener('mouseleave', () => {
	let state = player.getPlayerState();
	if (state === YT.PlayerState.PLAYING) { hideCenterImage(); }
	if (state === YT.PlayerState.PAUSED) { hideCenterImage(); }
});


function setupInitialVolume() {
	const savedVol = parseFloat(localStorage.getItem("ytVolume")) || 0;
	player.setVolume(savedVol * 100);
	updateVolumeLines(Math.round(savedVol * (lines.length - 1)));
}

function setupSeekControl() {
	seekingBox.addEventListener("click", (e) => {
		const rect = seekingBox.getBoundingClientRect();
		const clickX = e.clientX - rect.left;
		const totalDuration = player.getDuration();
		const clickedTime = (clickX / rect.width) * totalDuration;

		player.seekTo(clickedTime, true);
		wasSeekbarClickedFirstTime = true;

		const state = player.getPlayerState();

		// Only pause & show thumbnail/icon if video is NOT playing
		if (state !== YT.PlayerState.PLAYING) {
			setTimeout(() => {
				player.pauseVideo();
				showCenterIcon(false);
				setThumbnailVisibility(true);
			}, 100);
		}

		// Update range bar and time immediately
		range.style.width = `${(clickedTime / totalDuration) * 100}%`;
		currentTime.textContent = formatTime(clickedTime);
	});
}

function setupVolumeControl() {
	lines.forEach((line, index) => {
		line.addEventListener("click", () => {
			const volume = index / (lines.length - 1);
			player.setVolume(volume * 100);
			localStorage.setItem("ytVolume", volume.toFixed(2));
			updateVolumeLines(index);
		});
	});
}

function setupPlayPauseButtons() {
	smallPlayBtn.addEventListener("click", togglePlayPause);
	videoPlyBtn.addEventListener("click", togglePlayPause);

	smallPauseBtn.addEventListener("click", () => {
		player.seekTo(0, true);
		player.pauseVideo();
		range.style.width = `0%`;
		showCenterIcon(false);
		setThumbnailVisibility(true);

	});
}

function setupFullscreenButtons() {
	fullscreenBtnX.onclick = toggleFullscreen;
	fullScreenBtn.onclick = toggleFullscreen;
}

function setupOverlayHover() {
	videoOverlay.addEventListener('mouseenter', () => {
		const state = player.getPlayerState();
		showCenterIcon(state === YT.PlayerState.PLAYING);
	});
}

function showTotalDuration() {
	setTimeout(() => {
		const total = player.getDuration();
		totalDuration.textContent = formatTime(total);
	}, 1000);
}


function setThumbnailVisibility(show) {
	videoThubnail.style.display = show ? 'flex' : 'none';
}

window.addEventListener("message", (event) => {
	if (event.data === "disable-mouse") {
		document.body.style.pointerEvents = "none";
	} else if (event.data === "enable-mouse") {
		document.body.style.pointerEvents = "auto";
	}
});


videoPlyBtn.addEventListener("mouseleave", () => clearTimeout(fullScreenBtnHoverTimer));
fullScreenBtn.addEventListener("mouseleave", () => clearTimeout(fullScreenBtnHoverTimer));
