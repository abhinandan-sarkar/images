
//================DOM  SELECTOR===========

let query = (sel) => document.querySelector(sel);
let queryAll = (sel) => document.querySelectorAll(sel);

//================VARIABLE PART===========

let bannerImg = queryAll('.banner');
let video = query('video');
let index = 0;
let videoPlyBtn = query('.playBtnImg img');
let smallPauseBtn = query('.pause');
let smallPlayBtn = query('.play');
let currentTime = query('.currentTime');
let totalDuration = query('.durationTime');
let range = query('#range');
let lines = queryAll('.line');
let seekingBox = query('.seeking');
let articalBody = query('.artical-body');
let bigArtical = queryAll('.artical-big-item');
let arrowBig = queryAll('.arrow_big');
let fullScreenBtn = query('.full-screen img');
let videoContainer = query('.video-container');
let wrapper = query('#wrapper');
let forcePause = false;
let cursorTimeout;
let centerIconTimeout;
let hideControlsTimer;
const fullscreenBtnX = query('.full_screen');
let controlsWrapper = query('.full-video-control');
let videoWrapper = query('.video-wrapper');
let scrollYPosition = 0;
let playItemValue;

//===============INITIAL PROCESS==========

bannerImg.forEach((ele, val) => {
      ele.style.display = index === val ? `block` : `none`;
});

articalBody.addEventListener("mouseenter", () => {
      articalBody.style.border = `1px solid #3399cc`;
      articalBody.style.borderTop = `1px solid #cbcbcb`;
});

articalBody.addEventListener("mouseleave", () => {
      articalBody.style.border = `1px solid #cbcbcb`;
});

bigArtical.forEach((ele) => {
      ele.addEventListener("mouseenter", (e) => {
            e.target.style.border = `1px solid #3399cc`;
      });
      ele.addEventListener("mouseleave", (e) => {
            e.target.style.border = `1px solid #cbcbcb`;
      });
});

//============== BANNER ==================

let activeIndex = 0;
let intervalTimer = 4000;
let blinkInterval;

function blinkFn() {
      bannerImg[activeIndex].classList.remove('blink');
      activeIndex = (activeIndex + 1) % bannerImg.length;
      bannerImg[activeIndex].classList.add('blink');

      bannerImg.forEach((ele, val) => {
            ele.style.display = activeIndex === val ? `block` : `none`;
      });
}

blinkInterval = setInterval(blinkFn, intervalTimer);

query('.hero-img').addEventListener("mouseenter", () => {
      clearInterval(blinkInterval);
});

query('.hero-img').addEventListener("mouseleave", () => {
      blinkInterval = setInterval(blinkFn, intervalTimer);
});

//============ PLAY PAUSE BUTTON======

smallPlayBtn.addEventListener('click', toggleVideoPlayPause);
smallPauseBtn.addEventListener('click', smallPlayBtnFn);
videoPlyBtn.addEventListener('click', toggleVideoPlayPause);
fullScreenBtn.addEventListener("mouseenter", mouseEnterFn);

//==============VIDEO===========

video.addEventListener('play', () => {
      updatePlayPauseIcon(true);
      showCenterIcon(true);
      resetCenterHideTimer();
      videoPlyBtn.removeEventListener("mouseenter", mouseEnterFn);
      video.removeEventListener("mouseenter", mouseEnterFn);
      fullScreenBtn.removeEventListener("mouseenter", mouseEnterFn);
      resetCursorHideTimer();
      videoPlyBtn.style.pointerEvents = 'auto';
      fullScreenBtn.style.pointerEvents = 'none';
      showControls();
      hideControls();
});

video.addEventListener('pause', () => {
      clearTimeout(centerIconTimeout);
      clearTimeout(hideControlsTimer);
      if (document.fullscreenElement) {
        // Fullscreen + paused: keep visible indefinitely
        controlsWrapper.style.opacity = '1';
        controlsWrapper.style.pointerEvents = 'auto';

        // Show center icon (play button)
        showCenterIcon(false);
    } else {
        // Not fullscreen: keep old behavior
        showControls();
        hideControls();
    }
      videoPlyBtn.addEventListener("mouseenter", mouseEnterFn);
      fullScreenBtn.addEventListener("mouseenter", mouseEnterFn);
      video.addEventListener("mouseenter", mouseEnterFn);
      updatePlayPauseIcon(false);
      showCenterIcon(false);
      coursorBehavior();
      videoPlyBtn.style.cursor = 'pointer';
});

video.addEventListener('ended', () => {
      updatePlayPauseIcon(false);
      clearTimeout(centerIconTimeout);
      videoPlyBtn.style.opacity = '1';
      videoPlyBtn.style.pointerEvents = 'auto';
});

video.addEventListener('loadeddata', () => {
      totalDuration.textContent = formatTime(video.duration);
      const volumeIndex = Math.round(video.volume * (lines.length - 1));
      volumeArrowUpdate(volumeIndex);
      range.style.width = "0%";
});

video.addEventListener('timeupdate', () => {
      currentTime.textContent = formatTime(video.currentTime);
      const percent = (video.currentTime / video.duration) * 100;
      range.style.width = percent + "%";
});

video.addEventListener("mouseleave", () => {
      if (!document.fullscreenElement) {
            fullScreenBtn.style.opacity = '0';
            videoPlyBtn.style.opacity = '0';
      }
});

video.addEventListener("click", toggleVideoPlayPause);
videoPlyBtn.addEventListener("mouseenter", mouseEnterFn);

video.addEventListener("mousemove", () => {
      video.style.cursor = 'default';
      showCenterIcon(!video.paused);

      if (video.paused) {
            videoPlyBtn.style.cursor = 'pointer';
            clearTimeout(cursorTimeout);
            videoPlyBtn.addEventListener("mouseenter", mouseEnterFn);
            fullScreenBtn.addEventListener("mouseenter", mouseEnterFn);
      } else {
            resetCursorHideTimer();
            resetCenterHideTimer();
            videoPlyBtn.addEventListener("mouseenter", mouseEnterFn);
            fullScreenBtn.addEventListener("mouseenter", mouseEnterFn);
            video.addEventListener("mouseenter", mouseEnterFn);
      }
});

video.addEventListener('mouseenter', () => {
      if (video.paused) showCenterIcon(true);
});

//============== VOLUME ============== 

const savedVolume = localStorage.getItem('videoVolume');
video.volume = savedVolume ? parseFloat(savedVolume) : 0;

lines.forEach((line, index) => {
      line.addEventListener('click', () => {
            const volume = index / (lines.length - 1);
            video.volume = volume;
            localStorage.setItem('videoVolume', volume.toFixed(2));
            volumeArrowUpdate(index);
      });
});

//==============SEEK================

seekingBox.addEventListener("click", (event) => {
      const rect = seekingBox.getBoundingClientRect();
      const clickX = event.clientX - rect.left;
      const width = seekingBox.offsetWidth;
      video.currentTime = (clickX / width) * video.duration;
});

//=================FULL SCREEN===========

document.addEventListener('fullscreenchange', () => {
      if (document.fullscreenElement) {
            wrapper.classList.add('fullscreen-mode');
            fullScreenBtn.style.display = 'none';
      } else {
            wrapper.classList.remove('fullscreen-mode');
           // scrollTo(0, scrollYPosition)
           setTimeout(() => scrollTo(0, scrollYPosition), 60);
            fullScreenBtn.style.display = 'inline-block';
            fullScreenBtn.style.opacity = '0';
            
      }

      if (!document.fullscreenElement) {
            controlsWrapper.style.opacity = '1';
            controlsWrapper.style.pointerEvents = 'auto';
            clearTimeout(hideControlsTimer);
      } else {
            showControls();
            hideControls();
      }

      fullscreenBtnX.style.display = (document.fullscreenElement === videoWrapper) ? 'flex' : 'none';
});

fullScreenBtn.onclick = toggleFullscreen;
fullscreenBtnX.onclick = toggleFullscreen;

//=================BIG CONTROLLER======

videoWrapper.addEventListener('mousemove', () => {
      if (!document.fullscreenElement) return;
      showControls();
      hideControls();
});

videoWrapper.addEventListener('mouseenter', () => {
      if (!document.fullscreenElement) return;
      showControls();
      hideControls();
});

videoWrapper.addEventListener('mouseleave', () => {
      if (!document.fullscreenElement) return;
      clearTimeout(hideControlsTimer);
      controlsWrapper.style.opacity = '0';
      controlsWrapper.style.pointerEvents = 'none';
});

window.addEventListener('load', () => {
      controlsWrapper.style.opacity = '1';
      controlsWrapper.style.pointerEvents = 'auto';
});

//=====================CUSTOM FUNCTIONS============

function formatTime(seconds) {
      const min = Math.floor(seconds / 60);
      const sec = Math.floor(seconds % 60);
      return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
}

function updatePlayPauseIcon(isPlaying) {
      const playIcon = smallPlayBtn.querySelector('img');
      const bigPlayIcon = query('.playBtnImg img');
      const newSrc = isPlaying ? 'images/pause.svg' : 'images/play_button_small.svg';
      playIcon.src = newSrc;
      bigPlayIcon.src = newSrc;
}

function showControls() {
      if (!document.fullscreenElement) return;
      controlsWrapper.style.opacity = '1';
      controlsWrapper.style.pointerEvents = 'auto';
      videoPlyBtn.style.opacity = '0.6';
      videoPlyBtn.style.cursor='pointer';
      clearTimeout(hideControlsTimer);
}

function hideControls() {
      if (!document.fullscreenElement) return;
      hideControlsTimer = setTimeout(() => {
            controlsWrapper.style.opacity = '0';
            controlsWrapper.style.pointerEvents = 'none';
            videoPlyBtn.style.opacity = '0';
      }, 2000);
}

function toggleFullscreen() {
      if (!document.fullscreenElement) {
            scrollYPosition = scrollYPositionFn();
           setTimeout(() => wrapper.requestFullscreen(), 10);
            wrapper.requestFullscreen()
      } else {
            document.exitFullscreen();
            setTimeout(() => scrollTo(0, scrollYPosition), 100);
           //scrollTo(0, scrollYPosition)
      }
}

function volumeArrowUpdate(index) {
      lines.forEach((line, i) => {
            line.style.backgroundColor = i <= index ? '#fff' : '#333';
      });

      if (index === 0) {
            lines.forEach(line => line.style.backgroundColor = '#333');
      }
}

function showCenterIcon(isPlaying) {
      playItemValue = isPlaying;
      clearTimeout(centerIconTimeout);
      updatePlayPauseIcon(isPlaying);
      videoPlyBtn.style.opacity = '0.6';
      videoPlyBtn.style.cursor = 'pointer';
      fullScreenBtn.style.opacity = '0.6';
      fullScreenBtn.style.pointerEvents = 'auto';
}

function hideCenterImage() {
      if (video.paused) return;
      videoPlyBtn.style.opacity = '0';
      videoPlyBtn.style.cursor = 'none';
      fullScreenBtn.style.opacity = '0';
      fullScreenBtn.style.cursor = 'default';
      fullScreenBtn.style.pointerEvents = 'none';
}

function smallPlayBtnFn() {
      video.currentTime = 0;
      forcePause = true;
      clearTimeout(centerIconTimeout);
      video.pause();
      videoPlyBtn.style.opacity = '1';
      wrapper.style.pointerEvents = 'auto';
}

function toggleVideoPlayPause() {
      video.paused ? video.play() : video.pause();
}

function mouseEnterFn() {
      if (!document.fullscreenElement) {
            fullScreenBtn.style.opacity = '0.6';
            videoPlyBtn.style.opacity = '0.6';
            fullScreenBtn.style.pointerEvents = 'auto';
            fullScreenBtn.style.cursor = 'pointer';
            videoPlyBtn.style.cursor = 'pointer';
            videoPlyBtn.style.pointerEvents = 'auto';
      }
}

function coursorBehavior() {
      video.style.cursor = 'default';
}

function resetCursorHideTimer() {
      clearTimeout(cursorTimeout);
      video.style.cursor = 'default';
      videoPlyBtn.style.cursor = 'default';
      fullScreenBtn.style.cursor = 'default';

      cursorTimeout = setTimeout(() => {
            if (!video.paused) {
                  video.style.cursor = 'none';
                  videoPlyBtn.style.cursor = 'none';
                  fullScreenBtn.style.cursor = 'none';
            }
      }, 2000);
}

function resetCenterHideTimer() {
      clearTimeout(centerIconTimeout);
      if (video.paused) return;

      centerIconTimeout = setTimeout(() => {
            hideCenterImage();
      }, 2000);
}

function scrollYPositionFn(){
      return window.scrollY;
}

// 2. This code loads the IFrame Player API code asynchronously.
      var tag = document.createElement('script');

      tag.src = "https://www.youtube.com/iframe_api";
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

// 3. This function creates an <iframe> (and YouTube player)

      var player;
      function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
          height: '190',
          width: '290',
          videoId: 'M7lc1UVf-VE',
          playerVars: {
            'playsinline': 1
          },
          events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
          }
        });
      }

      // 4. The API will call this function when the video player is ready.
      function onPlayerReady(event) {
        event.target.playVideo();
      }

      // 5. The API calls this function when the player's state changes.
      //    The function indicates that when playing a video (state=1),
      //    the player should play for six seconds and then stop.
      var done = false;
      function onPlayerStateChange(event) {
        if (event.data == YT.PlayerState.PLAYING && !done) {
          setTimeout(stopVideo, 6000);
          done = true;
        }
      }
      function stopVideo() {
        player.stopVideo();
      }



